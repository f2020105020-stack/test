import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  Category, Product, Order, CartItem, OrderType, PaymentMethod,
  DeliveryCustomer, RestaurantTable, PrinterSettings, Role, WalletProvider,
} from "@/types/pos";
import { seedCategories, seedProducts, seedTables, defaultPrinterSettings } from "@/data/seed";

const uid = () => Math.random().toString(36).slice(2, 10);
const shortId = () => "R" + Math.floor(1000 + Math.random() * 9000);

interface AuthState {
  role: Role | null;
  username: string | null;
  login: (role: Role, username: string) => void;
  logout: () => void;
}

export const useAuth = create<AuthState>()(
  persist(
    (set) => ({
      role: null,
      username: null,
      login: (role, username) => set({ role, username }),
      logout: () => set({ role: null, username: null }),
    }),
    { name: "rush-auth" }
  )
);

interface POSState {
  categories: Category[];
  products: Product[];
  orders: Order[];
  customers: DeliveryCustomer[];
  tables: RestaurantTable[];
  printer: PrinterSettings;

  // Categories
  addCategory: (c: Omit<Category, "id">) => void;
  updateCategory: (id: string, patch: Partial<Category>) => void;
  deleteCategory: (id: string) => void;

  // Products
  addProduct: (p: Omit<Product, "id">) => void;
  updateProduct: (id: string, patch: Partial<Product>) => void;
  deleteProduct: (id: string) => void;

  // Orders
  createOrder: (data: {
    items: CartItem[];
    type: OrderType;
    cashier: string;
    tableId?: string;
    customer?: { name: string; phone: string; address: string; deliveryCharge: number };
    creditCustomerName?: string;
    paymentMethod?: PaymentMethod;
    walletProvider?: WalletProvider;
    senderPhone?: string;
    transactionId?: string;
    paymentRef?: string;
    notes?: string;
  }) => Order;
  updateOrder: (id: string, patch: Partial<Order>) => void;
  markReceived: (id: string) => void;
  markReady: (id: string) => void;
  markDelivered: (id: string) => void;
  payOrder: (id: string, method: PaymentMethod, extra?: { transactionId?: string; paymentRef?: string; walletProvider?: WalletProvider; senderPhone?: string }) => void;
  settleCredit: (id: string, method: PaymentMethod, extra?: { transactionId?: string; paymentRef?: string; walletProvider?: WalletProvider; senderPhone?: string }) => void;
  deleteOrder: (id: string, reason: string) => void;

  // Tables
  addTable: (t: Omit<RestaurantTable, "id" | "status">) => void;
  updateTable: (id: string, patch: Partial<RestaurantTable>) => void;
  deleteTable: (id: string) => void;
  freeTable: (id: string) => void;

  // Customers
  upsertCustomer: (c: Omit<DeliveryCustomer, "id" | "createdAt" | "totalOrders" | "totalRevenue"> & { id?: string }) => DeliveryCustomer;
  deleteCustomer: (id: string) => void;

  // Printer
  updatePrinter: (p: Partial<PrinterSettings>) => void;

  // Backup
  exportAll: () => string;
  importAll: (json: string) => void;
  resetAll: () => void;
}

export const usePOS = create<POSState>()(
  persist(
    (set, get) => ({
      categories: seedCategories,
      products: seedProducts,
      orders: [],
      customers: [],
      tables: seedTables,
      printer: defaultPrinterSettings,

      addCategory: (c) => set((s) => ({ categories: [...s.categories, { ...c, id: "cat-" + uid() }] })),
      updateCategory: (id, patch) =>
        set((s) => ({ categories: s.categories.map((c) => (c.id === id ? { ...c, ...patch } : c)) })),
      deleteCategory: (id) =>
        set((s) => ({
          categories: s.categories.filter((c) => c.id !== id),
          products: s.products.filter((p) => p.categoryId !== id),
        })),

      addProduct: (p) => set((s) => ({ products: [...s.products, { ...p, id: "p-" + uid() }] })),
      updateProduct: (id, patch) =>
        set((s) => ({ products: s.products.map((p) => (p.id === id ? { ...p, ...patch } : p)) })),
      deleteProduct: (id) => set((s) => ({ products: s.products.filter((p) => p.id !== id) })),

      createOrder: (data) => {
        const subtotal = data.items.reduce((a, i) => a + i.price * i.qty, 0);
        const discountTotal = data.items.reduce((a, i) => a + (i.discountAmount ?? 0), 0);
        const deliveryCharge = data.customer?.deliveryCharge ?? 0;
        const total = subtotal - discountTotal + deliveryCharge;

        let status: Order["status"] = "ongoing";
        if (data.paymentMethod === "credit") status = "credit";
        else if (data.paymentMethod) status = "paid";

        const order: Order = {
          id: uid(),
          shortId: shortId(),
          items: data.items,
          subtotal,
          discountTotal,
          deliveryCharge,
          total,
          type: data.type,
          status,
          paymentMethod: data.paymentMethod,
          walletProvider: data.walletProvider,
          senderPhone: data.senderPhone,
          transactionId: data.transactionId,
          paymentRef: data.paymentRef,
          tableId: data.tableId,
          customerName: data.customer?.name,
          customerPhone: data.customer?.phone,
          customerAddress: data.customer?.address,
          creditCustomerName: data.creditCustomerName,
          cashier: data.cashier,
          notes: data.notes,
          createdAt: Date.now(),
          paidAt: data.paymentMethod && data.paymentMethod !== "credit" ? Date.now() : undefined,
        };

        set((s) => ({ orders: [order, ...s.orders] }));

        if (data.tableId) {
          set((s) => ({
            tables: s.tables.map((t) =>
              t.id === data.tableId ? { ...t, status: "busy", currentOrderId: order.id } : t
            ),
          }));
        }

        if (data.customer?.phone) {
          get().upsertCustomer({
            name: data.customer.name,
            phone: data.customer.phone,
            address: data.customer.address,
            deliveryCharge: data.customer.deliveryCharge,
          });
          // Bump revenue
          set((s) => ({
            customers: s.customers.map((c) =>
              c.phone === data.customer!.phone
                ? { ...c, totalOrders: c.totalOrders + 1, totalRevenue: c.totalRevenue + total, lastOrderAt: Date.now() }
                : c
            ),
          }));
        }

        return order;
      },

      updateOrder: (id, patch) =>
        set((s) => ({ orders: s.orders.map((o) => (o.id === id ? { ...o, ...patch } : o)) })),

      markReceived: (id) =>
        set((s) => ({
          orders: s.orders.map((o) =>
            o.id === id ? { ...o, status: o.status === "ongoing" ? "received" : o.status, receivedAt: Date.now() } : o
          ),
        })),

      markReady: (id) =>
        set((s) => ({
          orders: s.orders.map((o) => (o.id === id ? { ...o, status: "ready", readyAt: Date.now() } : o)),
        })),

      markDelivered: (id) =>
        set((s) => ({
          orders: s.orders.map((o) => (o.id === id ? { ...o, status: "delivered", deliveredAt: Date.now() } : o)),
        })),

      payOrder: (id, method, extra) => {
        set((s) => ({
          orders: s.orders.map((o) =>
            o.id === id
              ? {
                  ...o,
                  paymentMethod: method,
                  status: method === "credit" ? "credit" : "paid",
                  paidAt: method === "credit" ? undefined : Date.now(),
                  transactionId: extra?.transactionId ?? o.transactionId,
                  paymentRef: extra?.paymentRef ?? o.paymentRef,
                  walletProvider: extra?.walletProvider ?? o.walletProvider,
                  senderPhone: extra?.senderPhone ?? o.senderPhone,
                }
              : o
          ),
        }));
        const order = get().orders.find((o) => o.id === id);
        if (order?.tableId && method !== "credit") get().freeTable(order.tableId);
      },

      settleCredit: (id, method, extra) => {
        set((s) => ({
          orders: s.orders.map((o) =>
            o.id === id
              ? {
                  ...o,
                  status: "paid",
                  creditSettledAt: Date.now(),
                  creditSettledMethod: method,
                  paidAt: Date.now(),
                  paymentMethod: method,
                  transactionId: extra?.transactionId ?? o.transactionId,
                  paymentRef: extra?.paymentRef ?? o.paymentRef,
                  walletProvider: extra?.walletProvider ?? o.walletProvider,
                  senderPhone: extra?.senderPhone ?? o.senderPhone,
                }
              : o
          ),
        }));
        const order = get().orders.find((o) => o.id === id);
        if (order?.tableId) get().freeTable(order.tableId);
      },

      deleteOrder: (id, reason) => {
        set((s) => ({
          orders: s.orders.map((o) =>
            o.id === id ? { ...o, status: "deleted", deletedAt: Date.now(), deleteReason: reason } : o
          ),
        }));
        const order = get().orders.find((o) => o.id === id);
        if (order?.tableId) get().freeTable(order.tableId);
      },

      addTable: (t) => set((s) => ({ tables: [...s.tables, { ...t, id: "t-" + uid(), status: "free" }] })),
      updateTable: (id, patch) =>
        set((s) => ({ tables: s.tables.map((t) => (t.id === id ? { ...t, ...patch } : t)) })),
      deleteTable: (id) => set((s) => ({ tables: s.tables.filter((t) => t.id !== id) })),
      freeTable: (id) =>
        set((s) => ({
          tables: s.tables.map((t) => (t.id === id ? { ...t, status: "free", currentOrderId: undefined } : t)),
        })),

      upsertCustomer: (c) => {
        const existing = get().customers.find((x) => x.phone === c.phone);
        if (existing) {
          const updated = { ...existing, name: c.name, address: c.address, deliveryCharge: c.deliveryCharge };
          set((s) => ({ customers: s.customers.map((x) => (x.id === existing.id ? updated : x)) }));
          return updated;
        }
        const created: DeliveryCustomer = {
          id: c.id ?? "cust-" + uid(),
          name: c.name,
          phone: c.phone,
          address: c.address,
          deliveryCharge: c.deliveryCharge,
          totalOrders: 0,
          totalRevenue: 0,
          createdAt: Date.now(),
        };
        set((s) => ({ customers: [created, ...s.customers] }));
        return created;
      },
      deleteCustomer: (id) => set((s) => ({ customers: s.customers.filter((c) => c.id !== id) })),

      updatePrinter: (p) => set((s) => ({ printer: { ...s.printer, ...p } })),

      exportAll: () => JSON.stringify({
        categories: get().categories,
        products: get().products,
        orders: get().orders,
        customers: get().customers,
        tables: get().tables,
        printer: get().printer,
      }, null, 2),

      importAll: (json) => {
        const d = JSON.parse(json);
        set({
          categories: d.categories ?? seedCategories,
          products: d.products ?? seedProducts,
          orders: d.orders ?? [],
          customers: d.customers ?? [],
          tables: d.tables ?? seedTables,
          printer: d.printer ?? defaultPrinterSettings,
        });
      },

      resetAll: () => set({
        categories: seedCategories,
        products: seedProducts,
        orders: [],
        customers: [],
        tables: seedTables,
        printer: defaultPrinterSettings,
      }),
    }),
    { name: "rush-pos" }
  )
);
