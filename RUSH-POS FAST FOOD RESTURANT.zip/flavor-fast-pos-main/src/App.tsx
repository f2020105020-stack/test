import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import Staff from "./pages/staff/Staff.tsx";
import Ongoing from "./pages/staff/Ongoing.tsx";
import Tables from "./pages/staff/Tables.tsx";
import Customers from "./pages/staff/Customers.tsx";
import Kitchen from "./pages/Kitchen.tsx";
import Admin from "./pages/Admin.tsx";
import { RequireRole } from "./components/RequireRole.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/staff" element={<RequireRole role="staff"><Staff /></RequireRole>} />
          <Route path="/staff/ongoing" element={<RequireRole role="staff"><Ongoing /></RequireRole>} />
          <Route path="/staff/tables" element={<RequireRole role="staff"><Tables /></RequireRole>} />
          <Route path="/staff/customers" element={<RequireRole role="staff"><Customers /></RequireRole>} />
          <Route path="/kitchen" element={<RequireRole role="kitchen"><Kitchen /></RequireRole>} />
          <Route path="/admin/*" element={<RequireRole role="admin"><Admin /></RequireRole>} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
