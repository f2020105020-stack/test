import { Category, Product, RestaurantTable, PrinterSettings } from "@/types/pos";

export const seedCategories: Category[] = [
  { id: "cat-burgers", name: "Burgers", emoji: "🍔" },
  { id: "cat-wings", name: "Wings", emoji: "🍗" },
  { id: "cat-pizza", name: "Pizza", emoji: "🍕" },
  { id: "cat-sides", name: "Sides", emoji: "🍟" },
  { id: "cat-drinks", name: "Drinks", emoji: "🥤" },
  { id: "cat-desserts", name: "Desserts", emoji: "🍰" },
];

export const seedProducts: Product[] = [
  { id: "p-1", name: "Classic Beef Burger", price: 450, categoryId: "cat-burgers", emoji: "🍔", available: true },
  { id: "p-2", name: "Chicken Zinger", price: 400, categoryId: "cat-burgers", emoji: "🍔", available: true },
  { id: "p-3", name: "Double Cheese Burger", price: 650, categoryId: "cat-burgers", emoji: "🍔", available: true },
  { id: "p-4", name: "Smoky BBQ Burger", price: 550, categoryId: "cat-burgers", emoji: "🍔", available: true },
  { id: "p-5", name: "BBQ Wings (6 pcs)", price: 550, categoryId: "cat-wings", emoji: "🍗", available: true },
  { id: "p-6", name: "Hot Buffalo Wings", price: 600, categoryId: "cat-wings", emoji: "🌶️", available: true },
  { id: "p-7", name: "Crispy Tenders", price: 480, categoryId: "cat-wings", emoji: "🍗", available: true },
  { id: "p-8", name: "Pepperoni Pizza", price: 1200, categoryId: "cat-pizza", emoji: "🍕", available: true },
  { id: "p-9", name: "Chicken Tikka Pizza", price: 1300, categoryId: "cat-pizza", emoji: "🍕", available: true },
  { id: "p-10", name: "Veggie Supreme", price: 1100, categoryId: "cat-pizza", emoji: "🍕", available: true },
  { id: "p-11", name: "French Fries", price: 150, categoryId: "cat-sides", emoji: "🍟", available: true },
  { id: "p-12", name: "Loaded Cheese Fries", price: 280, categoryId: "cat-sides", emoji: "🧀", available: true },
  { id: "p-13", name: "Onion Rings", price: 200, categoryId: "cat-sides", emoji: "🧅", available: true },
  { id: "p-14", name: "Coca Cola", price: 120, categoryId: "cat-drinks", emoji: "🥤", available: true },
  { id: "p-15", name: "Sprite", price: 120, categoryId: "cat-drinks", emoji: "🥤", available: true },
  { id: "p-16", name: "Fresh Lime", price: 150, categoryId: "cat-drinks", emoji: "🍋", available: true },
  { id: "p-17", name: "Chocolate Brownie", price: 250, categoryId: "cat-desserts", emoji: "🍫", available: true },
  { id: "p-18", name: "Vanilla Ice Cream", price: 180, categoryId: "cat-desserts", emoji: "🍦", available: true },
];

export const seedTables: RestaurantTable[] = Array.from({ length: 12 }, (_, i) => ({
  id: `t-${i + 1}`,
  number: String(i + 1).padStart(2, "0"),
  capacity: i % 3 === 0 ? 6 : i % 2 === 0 ? 4 : 2,
  status: "free",
}));

export const defaultPrinterSettings: PrinterSettings = {
  paperWidth: 80,
  headerLines: ["RUSH FAST FOOD", "Karachi, Pakistan", "Tel: 0300-1234567"],
  footerLines: ["Thank you for dining with RUSH!", "Follow us @rushfastfood"],
  autoPrint: false,
};
