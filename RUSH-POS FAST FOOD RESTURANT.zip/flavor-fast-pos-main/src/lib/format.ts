export const fmt = (n: number) => "Rs. " + Math.round(n).toLocaleString("en-PK");
