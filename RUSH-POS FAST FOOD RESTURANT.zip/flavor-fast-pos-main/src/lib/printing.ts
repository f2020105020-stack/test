import { Order, PrinterSettings, WALLET_PROVIDERS } from "@/types/pos";
import { format } from "date-fns";

const providerLabel = (v?: string) =>
  WALLET_PROVIDERS.find((w) => w.value === v)?.label ?? v ?? "";

const ESC = "\x1B";
const GS = "\x1D";

const center = "\x1B\x61\x01";
const left = "\x1B\x61\x00";
const boldOn = "\x1B\x45\x01";
const boldOff = "\x1B\x45\x00";
const cut = "\x1D\x56\x00";
const init = "\x1B\x40";
const dblOn = "\x1D\x21\x11";
const dblOff = "\x1D\x21\x00";

function line(width: number, ch = "-") { return ch.repeat(width); }
function pad(left: string, right: string, width: number) {
  const space = Math.max(1, width - left.length - right.length);
  return left + " ".repeat(space) + right;
}

export function buildReceiptText(order: Order, settings: PrinterSettings, kind: "kitchen" | "bill" | "payment" = "bill"): string {
  const W = settings.paperWidth === 58 ? 32 : 42;
  let s = "";
  s += init;
  s += center + dblOn + "RUSH\n" + dblOff;
  for (const h of settings.headerLines) s += center + h + "\n";
  s += center + line(W, "=") + "\n";
  s += center + boldOn + (kind === "kitchen" ? "KITCHEN COPY" : kind === "payment" ? "PAYMENT RECEIPT" : "CUSTOMER BILL") + boldOff + "\n";
  s += line(W, "=") + "\n";
  s += left;
  s += `Order: ${order.shortId}\n`;
  s += `Date : ${format(order.createdAt, "yyyy-MM-dd HH:mm")}\n`;
  s += `Type : ${order.type.toUpperCase()}\n`;
  if (order.tableId) s += `Table: ${order.tableId}\n`;
  if (order.customerName) s += `Cust : ${order.customerName}\n`;
  if (order.customerPhone) s += `Phone: ${order.customerPhone}\n`;
  s += `Cash : ${order.cashier}\n`;
  s += line(W) + "\n";
  for (const it of order.items) {
    s += `${it.qty}x ${it.name}\n`;
    if (kind !== "kitchen") {
      s += pad(`   @ Rs.${it.price.toFixed(0)}`, `Rs.${(it.price * it.qty).toFixed(0)}`, W) + "\n";
      if (it.discountAmount) s += pad(`   disc`, `-Rs.${it.discountAmount.toFixed(0)}`, W) + "\n";
    }
  }
  if (kind !== "kitchen") {
    s += line(W) + "\n";
    s += pad("Subtotal", `Rs.${order.subtotal.toFixed(0)}`, W) + "\n";
    if (order.discountTotal) s += pad("Discount", `-Rs.${order.discountTotal.toFixed(0)}`, W) + "\n";
    if (order.deliveryCharge) s += pad("Delivery", `Rs.${order.deliveryCharge.toFixed(0)}`, W) + "\n";
    s += boldOn + pad("TOTAL", `Rs.${order.total.toFixed(0)}`, W) + boldOff + "\n";
    if (order.paymentMethod) {
      const via = order.walletProvider
        ? `${order.paymentMethod.toUpperCase()}/${providerLabel(order.walletProvider).toUpperCase()}`
        : order.paymentMethod.toUpperCase();
      s += pad("Paid via", via, W) + "\n";
    }
    if (order.senderPhone) s += `From: ${order.senderPhone}\n`;
    if (order.transactionId) s += `Txn : ${order.transactionId}\n`;
    if (order.paymentRef) s += `Ref : ${order.paymentRef}\n`;
  }
  s += line(W, "=") + "\n";
  for (const f of settings.footerLines) s += center + f + "\n";
  s += "\n\n\n" + cut;
  return s;
}

// ---- Web Bluetooth ESC/POS ----
const PRINTER_SERVICE = "000018f0-0000-1000-8000-00805f9b34fb";
const PRINTER_CHAR = "00002af1-0000-1000-8000-00805f9b34fb";

let cachedDevice: any = null;
let cachedChar: any = null;

export async function connectPrinter(): Promise<string> {
  // @ts-ignore
  if (!navigator.bluetooth) throw new Error("Web Bluetooth not supported in this browser. Use Chrome or Edge on desktop/Android.");
  // @ts-ignore
  const device: any = await (navigator as any).bluetooth.requestDevice({
    acceptAllDevices: true,
    optionalServices: [PRINTER_SERVICE, "0000ff00-0000-1000-8000-00805f9b34fb", "000018f0-0000-1000-8000-00805f9b34fb"],
  });
  const server = await device.gatt!.connect();
  // Try the common service first, fall back to enumerating
  let char: any = null;
  try {
    const svc = await server.getPrimaryService(PRINTER_SERVICE);
    char = await svc.getCharacteristic(PRINTER_CHAR);
  } catch {
    const services = await server.getPrimaryServices();
    for (const svc of services) {
      const chars = await svc.getCharacteristics();
      const writable = chars.find((c) => c.properties.write || c.properties.writeWithoutResponse);
      if (writable) { char = writable; break; }
    }
  }
  if (!char) throw new Error("No writable characteristic found on printer.");
  cachedDevice = device;
  cachedChar = char;
  return device.name ?? "Unknown printer";
}

export function getConnectedPrinter() {
  return cachedDevice?.name ?? null;
}

export async function printText(text: string) {
  if (!cachedChar) throw new Error("Printer not connected. Pair it from Admin > Printer.");
  const enc = new TextEncoder();
  const data = enc.encode(text);
  // Write in 200-byte chunks
  const chunk = 200;
  for (let i = 0; i < data.length; i += chunk) {
    const slice = data.slice(i, i + chunk);
    if (cachedChar.properties.writeWithoutResponse) await cachedChar.writeValueWithoutResponse(slice);
    else await cachedChar.writeValue(slice);
  }
}

export function browserPrint(html: string) {
  const w = window.open("", "_blank", "width=420,height=640");
  if (!w) return;
  w.document.write(`<html><head><title>RUSH Receipt</title>
    <style>
      @page { margin: 4mm; size: 80mm auto; }
      body { font-family: 'JetBrains Mono', monospace; font-size: 12px; color: #000; margin: 0; padding: 8px; }
      .center { text-align: center; }
      .row { display: flex; justify-content: space-between; }
      .bold { font-weight: 700; }
      .sep { border-top: 1px dashed #000; margin: 4px 0; }
      h1 { font-size: 22px; margin: 4px 0; letter-spacing: 2px; }
      table { width: 100%; border-collapse: collapse; }
      td { padding: 2px 0; }
    </style></head><body>${html}<script>window.onload=()=>{window.print();setTimeout(()=>window.close(),300);}</script></body></html>`);
  w.document.close();
}
