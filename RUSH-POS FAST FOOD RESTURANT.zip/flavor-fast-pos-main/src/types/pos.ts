export type Role = "staff" | "kitchen" | "admin";

export type OrderType = "dine-in" | "takeaway" | "delivery";
export type PaymentMethod = "cash" | "card" | "online" | "credit";
export type WalletProvider =
  | "jazzcash"
  | "easypaisa"
  | "sadapay"
  | "nayapay"
  | "upaisa"
  | "bank-transfer"
  | "other";

export const WALLET_PROVIDERS: { value: WalletProvider; label: string; emoji: string }[] = [
  { value: "jazzcash",      label: "JazzCash",      emoji: "📱" },
  { value: "easypaisa",     label: "Easypaisa",     emoji: "💚" },
  { value: "sadapay",       label: "SadaPay",       emoji: "💳" },
  { value: "nayapay",       label: "NayaPay",       emoji: "🟣" },
  { value: "upaisa",        label: "UPaisa",        emoji: "🟠" },
  { value: "bank-transfer", label: "Bank Transfer", emoji: "🏦" },
  { value: "other",         label: "Other Wallet",  emoji: "💼" },
];
export type OrderStatus = "ongoing" | "received" | "ready" | "delivered" | "paid" | "credit" | "deleted";

export interface Category {
  id: string;
  name: string;
  emoji: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  categoryId: string;
  emoji: string;
  available: boolean;
}

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  qty: number;
  emoji: string;
  discountType?: "rs" | "pct";
  discountValue?: number;
  discountAmount?: number;
  discountReason?: string;
}

export interface DeliveryCustomer {
  id: string;
  name: string;
  phone: string;
  address: string;
  deliveryCharge: number;
  totalOrders: number;
  totalRevenue: number;
  lastOrderAt?: number;
  createdAt: number;
}

export interface RestaurantTable {
  id: string;
  number: string;
  capacity: number;
  status: "free" | "busy";
  currentOrderId?: string;
}

export interface Order {
  id: string;
  shortId: string;
  items: CartItem[];
  subtotal: number;
  discountTotal: number;
  deliveryCharge: number;
  total: number;
  type: OrderType;
  status: OrderStatus;
  paymentMethod?: PaymentMethod;
  walletProvider?: WalletProvider;
  senderPhone?: string;
  transactionId?: string;
  paymentRef?: string;
  tableId?: string;
  customerId?: string;
  customerName?: string;
  customerPhone?: string;
  customerAddress?: string;
  creditCustomerName?: string;
  creditSettledAt?: number;
  creditSettledMethod?: PaymentMethod;
  cashier: string;
  notes?: string;
  createdAt: number;
  receivedAt?: number;
  readyAt?: number;
  deliveredAt?: number;
  paidAt?: number;
  deletedAt?: number;
  deleteReason?: string;
}

export interface PrinterSettings {
  deviceName?: string;
  paperWidth: 58 | 80;
  headerLines: string[];
  footerLines: string[];
  autoPrint: boolean;
}
