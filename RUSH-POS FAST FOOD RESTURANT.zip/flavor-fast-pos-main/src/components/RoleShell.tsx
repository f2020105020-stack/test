import { Link, useLocation, useNavigate } from "react-router-dom";
import { LogOut } from "lucide-react";
import logo from "@/assets/rush-logo.png";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/store/pos";
import { cn } from "@/lib/utils";

interface NavItem { to: string; label: string; icon?: React.ReactNode }

export const RoleShell = ({
  title,
  accent,
  nav,
  children,
}: {
  title: string;
  accent: "primary" | "accent" | "secondary";
  nav?: NavItem[];
  children: React.ReactNode;
}) => {
  const { username, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const handleLogout = () => { logout(); navigate("/"); };

  const accentBar = accent === "primary" ? "bg-gradient-primary" : accent === "accent" ? "bg-gradient-accent" : "bg-gradient-dark";

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="bg-secondary text-secondary-foreground border-b border-secondary/40 sticky top-0 z-40">
        <div className={cn("h-1", accentBar)} />
        <div className="px-4 md:px-6 py-3 flex items-center gap-4">
          <Link to={`/${useAuth.getState().role}`} className="flex items-center gap-3">
            <img src={logo} alt="RUSH" width={40} height={40} className="w-10 h-10 object-contain" />
            <div>
              <div className="font-display text-2xl leading-none">RUSH <span className="text-primary">POS</span></div>
              <div className="text-xs uppercase tracking-widest text-secondary-foreground/60">{title}</div>
            </div>
          </Link>
          {nav && (
            <nav className="hidden md:flex items-center gap-1 ml-6 overflow-x-auto scrollbar-thin">
              {nav.map((n) => {
                const active = location.pathname === n.to || (n.to !== `/${useAuth.getState().role}` && location.pathname.startsWith(n.to));
                return (
                  <Link
                    key={n.to}
                    to={n.to}
                    className={cn(
                      "px-3 py-2 rounded-md text-sm font-medium whitespace-nowrap transition",
                      active
                        ? "bg-primary text-primary-foreground"
                        : "text-secondary-foreground/80 hover:bg-secondary-foreground/10"
                    )}
                  >
                    {n.icon}
                    <span className={cn(n.icon && "ml-1.5")}>{n.label}</span>
                  </Link>
                );
              })}
            </nav>
          )}
          <div className="ml-auto flex items-center gap-3">
            <div className="hidden sm:flex flex-col items-end leading-tight">
              <span className="text-sm font-semibold">{username}</span>
              <span className="text-[10px] uppercase tracking-widest text-secondary-foreground/60">{useAuth.getState().role}</span>
            </div>
            <Button size="sm" variant="ghost" className="text-secondary-foreground hover:bg-secondary-foreground/10" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-1" /> Logout
            </Button>
          </div>
        </div>
        {nav && (
          <nav className="md:hidden flex items-center gap-1 px-2 pb-2 overflow-x-auto scrollbar-thin">
            {nav.map((n) => {
              const active = location.pathname === n.to;
              return (
                <Link key={n.to} to={n.to}
                  className={cn("px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap",
                    active ? "bg-primary text-primary-foreground" : "bg-secondary-foreground/10 text-secondary-foreground")}>
                  {n.label}
                </Link>
              );
            })}
          </nav>
        )}
      </header>
      <main className="flex-1 min-h-0">{children}</main>
    </div>
  );
};
