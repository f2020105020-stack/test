import { Order, PrinterSettings, WALLET_PROVIDERS } from "@/types/pos";
import { format } from "date-fns";
import { fmt } from "@/lib/format";

const providerLabel = (v?: string) =>
  WALLET_PROVIDERS.find((w) => w.value === v)?.label ?? v ?? "";

export const ReceiptHTML = ({ order, settings, kind = "bill" }: { order: Order; settings: PrinterSettings; kind?: "kitchen" | "bill" | "payment" }) => {
  return (
    <div className="print-area">
      <div className="center">
        <h1>RUSH</h1>
        {settings.headerLines.map((h, i) => <div key={i}>{h}</div>)}
        <div className="sep" />
        <strong>{kind === "kitchen" ? "KITCHEN COPY" : kind === "payment" ? "PAYMENT RECEIPT" : "CUSTOMER BILL"}</strong>
      </div>
      <div className="sep" />
      <div>Order: <strong>{order.shortId}</strong></div>
      <div>Date: {format(order.createdAt, "yyyy-MM-dd HH:mm")}</div>
      <div>Type: {order.type.toUpperCase()}</div>
      {order.tableId && <div>Table: {order.tableId}</div>}
      {order.customerName && <div>Customer: {order.customerName}</div>}
      {order.customerPhone && <div>Phone: {order.customerPhone}</div>}
      {order.customerAddress && <div>Address: {order.customerAddress}</div>}
      <div>Cashier: {order.cashier}</div>
      <div className="sep" />
      <table>
        <tbody>
          {order.items.map((i) => (
            <tr key={i.productId}>
              <td>{i.qty}× {i.name}{kind !== "kitchen" && <div style={{ fontSize: 10, color: "#555" }}>@ {fmt(i.price)}</div>}</td>
              {kind !== "kitchen" && <td style={{ textAlign: "right" }}>{fmt(i.price * i.qty - (i.discountAmount ?? 0))}</td>}
            </tr>
          ))}
        </tbody>
      </table>
      {kind !== "kitchen" && (
        <>
          <div className="sep" />
          <div className="row"><span>Subtotal</span><span>{fmt(order.subtotal)}</span></div>
          {order.discountTotal > 0 && <div className="row"><span>Discount</span><span>− {fmt(order.discountTotal)}</span></div>}
          {order.deliveryCharge > 0 && <div className="row"><span>Delivery</span><span>{fmt(order.deliveryCharge)}</span></div>}
          <div className="row bold" style={{ fontSize: 16, marginTop: 4 }}><span>TOTAL</span><span>{fmt(order.total)}</span></div>
          {order.paymentMethod && <div className="row"><span>Paid via</span><span>{order.paymentMethod.toUpperCase()}{order.walletProvider ? ` · ${providerLabel(order.walletProvider).toUpperCase()}` : ""}</span></div>}
          {order.senderPhone && <div>From: {order.senderPhone}</div>}
          {order.transactionId && <div>Txn: {order.transactionId}</div>}
          {order.paymentRef && <div>Ref: {order.paymentRef}</div>}
        </>
      )}
      {order.notes && <><div className="sep" /><div>Notes: {order.notes}</div></>}
      <div className="sep" />
      <div className="center">
        {settings.footerLines.map((f, i) => <div key={i}>{f}</div>)}
        <div style={{ marginTop: 8, fontSize: 10 }}>{format(Date.now(), "yyyy-MM-dd HH:mm:ss")}</div>
      </div>
    </div>
  );
};
