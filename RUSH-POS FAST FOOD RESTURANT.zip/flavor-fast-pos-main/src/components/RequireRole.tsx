import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/store/pos";
import { Role } from "@/types/pos";

export const RequireRole = ({ role, children }: { role: Role; children: React.ReactNode }) => {
  const { role: current } = useAuth();
  const location = useLocation();
  if (!current) return <Navigate to="/" state={{ from: location }} replace />;
  if (current !== role) return <Navigate to={`/${current}`} replace />;
  return <>{children}</>;
};
