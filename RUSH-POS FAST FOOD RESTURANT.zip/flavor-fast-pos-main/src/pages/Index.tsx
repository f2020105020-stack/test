import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChefHat, Shield, ShoppingBag, Lock, User } from "lucide-react";
import { useAuth } from "@/store/pos";
import { Role } from "@/types/pos";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import logo from "@/assets/rush-logo.png";
import hero from "@/assets/hero-burger.jpg";
import { cn } from "@/lib/utils";

const ROLE_DEFS: { id: Role; title: string; tagline: string; icon: any; user: string; pass: string; color: string }[] = [
  { id: "staff",   title: "Staff / Cashier", tagline: "Take orders & process payments", icon: ShoppingBag, user: "staff",   pass: "staff",          color: "from-primary to-primary-glow" },
  { id: "kitchen", title: "Kitchen",         tagline: "Receive, cook & mark ready",     icon: ChefHat,    user: "kitchen", pass: "kitchen",        color: "from-accent to-warning" },
  { id: "admin",   title: "Admin / Manager", tagline: "Reports, products & settings",   icon: Shield,     user: "RUSH",    pass: "rushbeefburger", color: "from-secondary to-foreground" },
];

const Index = () => {
  const [selected, setSelected] = useState<Role | null>(null);
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const navigate = useNavigate();
  const login = useAuth((s) => s.login);

  const def = ROLE_DEFS.find((r) => r.id === selected);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!def) return;
    if (u.trim() === def.user && p === def.pass) {
      login(def.id, def.user);
      toast.success(`Welcome, ${def.user}`);
      navigate(`/${def.id}`);
    } else {
      toast.error("Invalid credentials");
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col lg:flex-row">
      {/* Left: hero brand */}
      <section className="relative lg:w-1/2 min-h-[40vh] lg:min-h-screen overflow-hidden">
        <img src={hero} alt="" className="absolute inset-0 w-full h-full object-cover" width={1280} height={896} />
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="relative z-10 h-full flex flex-col justify-between p-8 md:p-12 text-white">
          <div className="flex items-center gap-3">
            <img src={logo} alt="RUSH" width={56} height={56} className="w-14 h-14 object-contain drop-shadow-lg" />
            <div>
              <div className="font-display text-3xl md:text-4xl leading-none">RUSH</div>
              <div className="text-xs uppercase tracking-[0.3em] text-white/70">Fast Food POS</div>
            </div>
          </div>
          <div className="max-w-md">
            <h1 className="font-display text-5xl md:text-7xl leading-[0.9] text-balance">
              Serve faster.<br />
              <span className="text-primary-foreground bg-primary px-2">Sell smarter.</span>
            </h1>
            <p className="mt-6 text-white/80 text-lg max-w-sm">
              The complete point-of-sale built for the rush. Three roles, one beautiful kitchen-floor system.
            </p>
            <div className="mt-8 flex flex-wrap gap-2 text-xs uppercase tracking-widest text-white/60">
              <span>Dine-In</span><span>·</span><span>Takeaway</span><span>·</span><span>Delivery</span><span>·</span><span>Credit</span>
            </div>
          </div>
        </div>
      </section>

      {/* Right: login */}
      <section className="lg:w-1/2 flex items-center justify-center p-6 md:p-12">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <div className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Sign in to continue</div>
            <h2 className="font-display text-4xl mt-1">Choose your station</h2>
          </div>

          <div className="grid grid-cols-3 gap-2 mb-6">
            {ROLE_DEFS.map((r) => {
              const Icon = r.icon;
              const active = selected === r.id;
              return (
                <button
                  key={r.id}
                  onClick={() => { setSelected(r.id); setU(r.user); setP(""); }}
                  className={cn(
                    "group relative rounded-lg border-2 p-3 text-left transition-all",
                    active
                      ? "border-primary bg-primary/5 shadow-glow"
                      : "border-border hover:border-primary/40 hover:-translate-y-0.5"
                  )}
                >
                  <div className={cn("w-10 h-10 rounded-md flex items-center justify-center bg-gradient-to-br text-white mb-2", r.color)}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="text-sm font-semibold leading-tight">{r.title}</div>
                </button>
              );
            })}
          </div>

          {def ? (
            <form onSubmit={submit} className="space-y-4 animate-fade-in">
              <p className="text-sm text-muted-foreground">{def.tagline}</p>
              <div>
                <Label htmlFor="u">Username</Label>
                <div className="relative mt-1.5">
                  <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input id="u" value={u} onChange={(e) => setU(e.target.value)} className="pl-9 h-11" autoFocus />
                </div>
              </div>
              <div>
                <Label htmlFor="p">Password</Label>
                <div className="relative mt-1.5">
                  <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input id="p" type="password" value={p} onChange={(e) => setP(e.target.value)} className="pl-9 h-11" />
                </div>
              </div>
              <Button type="submit" size="lg" className="w-full h-12 text-base bg-gradient-primary hover:opacity-95 shadow-glow">
                Enter {def.title.split(" / ")[0]}
              </Button>
              <div className="text-xs text-muted-foreground bg-muted rounded-md px-3 py-2">
                Demo: <span className="font-mono font-semibold">{def.user}</span> / <span className="font-mono font-semibold">{def.pass}</span>
              </div>
            </form>
          ) : (
            <div className="text-center text-muted-foreground py-12 border border-dashed rounded-lg">
              Pick a role above to sign in
            </div>
          )}

          <div className="mt-10 text-center text-xs text-muted-foreground">
            © {new Date().getFullYear()} RUSH Fast Food · v1.0
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
