import { RoleShell } from "@/components/RoleShell";
import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChefHat, Clock, Check, Bike, Printer, ShoppingBag, UtensilsCrossed } from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { fmt } from "@/lib/format";
import { browserPrint } from "@/lib/printing";
import { ReceiptHTML } from "@/components/ReceiptHTML";
import { renderToString } from "react-dom/server";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";

const Kitchen = () => {
  const { orders, printer, markReceived, markReady, markDelivered } = usePOS();
  const [, force] = useState(0);

  // re-render every 30s for "ago" strings
  useEffect(() => {
    const t = setInterval(() => force((x) => x + 1), 30000);
    return () => clearInterval(t);
  }, []);

  const queue = orders.filter((o) => ["ongoing", "received", "ready"].includes(o.status))
    .sort((a, b) => a.createdAt - b.createdAt);

  const print = (id: string) => {
    const o = orders.find((x) => x.id === id);
    if (!o) return;
    browserPrint(renderToString(<ReceiptHTML order={o} settings={printer} kind="kitchen" />));
  };

  const TypeIcon = ({ t }: { t: string }) =>
    t === "delivery" ? <Bike className="w-4 h-4" /> :
    t === "takeaway" ? <ShoppingBag className="w-4 h-4" /> : <UtensilsCrossed className="w-4 h-4" />;

  const sections = [
    { key: "ongoing", title: "New", color: "border-primary", badge: "bg-primary" },
    { key: "received", title: "Cooking", color: "border-accent", badge: "bg-accent text-accent-foreground" },
    { key: "ready", title: "Ready", color: "border-success", badge: "bg-success text-success-foreground" },
  ] as const;

  return (
    <RoleShell title="Kitchen Display" accent="accent">
      <div className="p-4 md:p-6 max-w-[1600px] mx-auto">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div>
            <h2 className="font-display text-4xl flex items-center gap-2"><ChefHat className="w-8 h-8 text-accent" /> Kitchen Display</h2>
            <p className="text-sm text-muted-foreground">Live queue · {queue.length} active orders</p>
          </div>
          <div className="text-3xl font-display font-bold text-primary">{format(Date.now(), "HH:mm")}</div>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          {sections.map((s) => {
            const list = queue.filter((o) => o.status === s.key);
            return (
              <div key={s.key} className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge className={s.badge}>{s.title}</Badge>
                  <span className="text-sm text-muted-foreground">{list.length}</span>
                </div>
                {list.length === 0 && <div className="text-center py-8 text-muted-foreground text-sm border border-dashed rounded-lg">— Empty —</div>}
                {list.map((o) => {
                  const ageMin = (Date.now() - o.createdAt) / 60000;
                  const urgent = ageMin > 15;
                  return (
                    <Card key={o.id} className={cn("p-4 border-l-4 animate-fade-in", s.color, urgent && "ring-2 ring-destructive animate-pulse-glow")}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-display text-2xl">{o.shortId}</div>
                        <Badge variant="outline" className="capitalize"><TypeIcon t={o.type} /><span className="ml-1">{o.type.replace("-", " ")}</span></Badge>
                      </div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1 mb-3">
                        <Clock className="w-3 h-3" /> {formatDistanceToNow(o.createdAt, { addSuffix: true })}
                        {o.tableId && <span>· Table {o.tableId}</span>}
                      </div>
                      <ul className="space-y-1 mb-3">
                        {o.items.map((i) => (
                          <li key={i.productId} className="flex items-baseline gap-2">
                            <span className="font-display text-2xl text-primary leading-none">{i.qty}×</span>
                            <span className="font-medium text-base">{i.name}</span>
                          </li>
                        ))}
                      </ul>
                      {o.notes && <div className="text-xs bg-warning/20 border border-warning/40 rounded p-2 mb-3">📝 {o.notes}</div>}
                      <div className="flex flex-wrap gap-1.5">
                        <Button size="sm" variant="outline" onClick={() => print(o.id)}><Printer className="w-3 h-3 mr-1" />Print</Button>
                        {s.key === "ongoing" && (
                          <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={() => { markReceived(o.id); toast.success("Cooking " + o.shortId); }}>
                            <Check className="w-3 h-3 mr-1" /> Received
                          </Button>
                        )}
                        {s.key === "received" && (
                          <Button size="sm" className="bg-success text-success-foreground hover:bg-success/90" onClick={() => { markReady(o.id); toast.success("Ready: " + o.shortId); }}>
                            <Check className="w-3 h-3 mr-1" /> Mark Ready
                          </Button>
                        )}
                        {s.key === "ready" && o.type === "delivery" && (
                          <Button size="sm" className="bg-primary" onClick={() => { markDelivered(o.id); toast.success("Out for delivery"); }}>
                            <Bike className="w-3 h-3 mr-1" /> Delivered
                          </Button>
                        )}
                      </div>
                    </Card>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </RoleShell>
  );
};

export default Kitchen;
