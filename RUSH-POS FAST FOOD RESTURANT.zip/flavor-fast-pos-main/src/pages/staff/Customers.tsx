import { RoleShell } from "@/components/RoleShell";
import { usePOS } from "@/store/pos";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Phone, MapPin, Trash2 } from "lucide-react";
import { useState } from "react";
import { fmt } from "@/lib/format";
import { format } from "date-fns";

const STAFF_NAV = [
  { to: "/staff", label: "POS" },
  { to: "/staff/ongoing", label: "Ongoing" },
  { to: "/staff/tables", label: "Tables" },
  { to: "/staff/customers", label: "Delivery Book" },
];

const Customers = () => {
  const { customers, deleteCustomer } = usePOS();
  const [q, setQ] = useState("");
  const filtered = customers.filter((c) => c.name.toLowerCase().includes(q.toLowerCase()) || c.phone.includes(q));

  return (
    <RoleShell title="Delivery Customers" accent="primary" nav={STAFF_NAV}>
      <div className="p-4 md:p-6 max-w-5xl mx-auto">
        <h2 className="font-display text-3xl mb-4">Delivery Book <Badge className="ml-2">{customers.length}</Badge></h2>
        <div className="relative mb-4">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or phone…" className="pl-9 h-11" />
        </div>
        {filtered.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground border border-dashed rounded-lg">
            No customers yet — they'll be saved automatically when you take a delivery order.
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-3">
            {filtered.map((c) => (
              <Card key={c.id} className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-semibold">{c.name}</div>
                    <div className="text-sm text-muted-foreground flex items-center gap-1"><Phone className="w-3 h-3" />{c.phone}</div>
                    <div className="text-sm text-muted-foreground flex items-start gap-1 mt-1"><MapPin className="w-3 h-3 mt-0.5" />{c.address}</div>
                  </div>
                  <Button size="icon" variant="ghost" className="text-destructive" onClick={() => deleteCustomer(c.id)}><Trash2 className="w-4 h-4" /></Button>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t text-center text-xs">
                  <div><div className="font-display text-xl text-primary">{c.totalOrders}</div><div className="text-muted-foreground">Orders</div></div>
                  <div><div className="font-display text-xl">{fmt(c.totalRevenue)}</div><div className="text-muted-foreground">Revenue</div></div>
                  <div><div className="font-display text-xl">{fmt(c.deliveryCharge)}</div><div className="text-muted-foreground">Delivery</div></div>
                </div>
                {c.lastOrderAt && <div className="text-[10px] text-muted-foreground mt-2">Last order: {format(c.lastOrderAt, "yyyy-MM-dd HH:mm")}</div>}
              </Card>
            ))}
          </div>
        )}
      </div>
    </RoleShell>
  );
};

export default Customers;
