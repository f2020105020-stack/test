import { useMemo, useState } from "react";
import { RoleShell } from "@/components/RoleShell";
import { usePOS, useAuth } from "@/store/pos";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import {
  Plus, Minus, Trash2, Search, Tag, ShoppingCart, Receipt,
  Bike, UtensilsCrossed, ShoppingBag, CreditCard, Banknote, Wallet, Smartphone, Printer, X, Check
} from "lucide-react";
import { fmt } from "@/lib/format";
import { CartItem, OrderType, PaymentMethod, WalletProvider, WALLET_PROVIDERS } from "@/types/pos";
import { toast } from "sonner";
import { buildReceiptText, browserPrint, printText } from "@/lib/printing";
import { ReceiptHTML } from "@/components/ReceiptHTML";
import { renderToString } from "react-dom/server";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";

const STAFF_NAV = [
  { to: "/staff", label: "POS" },
  { to: "/staff/ongoing", label: "Ongoing" },
  { to: "/staff/tables", label: "Tables" },
  { to: "/staff/customers", label: "Delivery Book" },
];

const Staff = () => {
  const { categories, products, customers, tables, printer, createOrder } = usePOS();
  const { username } = useAuth();

  const [search, setSearch] = useState("");
  const [activeCat, setActiveCat] = useState<string>("all");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orderType, setOrderType] = useState<OrderType>("dine-in");
  const [tableId, setTableId] = useState<string | undefined>();
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerAddress, setCustomerAddress] = useState("");
  const [deliveryCharge, setDeliveryCharge] = useState(0);
  const [notes, setNotes] = useState("");

  // Discount dialog
  const [discountFor, setDiscountFor] = useState<string | null>(null);
  const [dType, setDType] = useState<"rs" | "pct">("rs");
  const [dValue, setDValue] = useState(0);
  const [dReason, setDReason] = useState("");

  // Payment dialog
  const [payOpen, setPayOpen] = useState(false);
  const [payMethod, setPayMethod] = useState<PaymentMethod>("cash");
  const [walletProvider, setWalletProvider] = useState<WalletProvider>("jazzcash");
  const [senderPhone, setSenderPhone] = useState("");
  const [txnId, setTxnId] = useState("");
  const [payRef, setPayRef] = useState("");
  const [creditName, setCreditName] = useState("");

  const filtered = useMemo(() => {
    return products.filter((p) =>
      p.available &&
      (activeCat === "all" || p.categoryId === activeCat) &&
      (search === "" || p.name.toLowerCase().includes(search.toLowerCase()))
    );
  }, [products, activeCat, search]);

  const subtotal = cart.reduce((a, i) => a + i.price * i.qty, 0);
  const discountTotal = cart.reduce((a, i) => a + (i.discountAmount ?? 0), 0);
  const total = subtotal - discountTotal + (orderType === "delivery" ? deliveryCharge : 0);

  const addToCart = (productId: string) => {
    const p = products.find((x) => x.id === productId)!;
    setCart((c) => {
      const idx = c.findIndex((i) => i.productId === productId);
      if (idx >= 0) { const copy = [...c]; copy[idx] = { ...copy[idx], qty: copy[idx].qty + 1 }; return copy; }
      return [...c, { productId, name: p.name, price: p.price, qty: 1, emoji: p.emoji }];
    });
  };
  const setQty = (id: string, qty: number) => {
    if (qty <= 0) return removeFromCart(id);
    setCart((c) => c.map((i) => (i.productId === id ? { ...i, qty } : i)));
  };
  const removeFromCart = (id: string) => setCart((c) => c.filter((i) => i.productId !== id));
  const clearCart = () => { setCart([]); setNotes(""); setTableId(undefined); setCustomerName(""); setCustomerPhone(""); setCustomerAddress(""); setDeliveryCharge(0); };

  const openDiscount = (id: string) => {
    const item = cart.find((i) => i.productId === id);
    setDiscountFor(id);
    setDType(item?.discountType ?? "rs");
    setDValue(item?.discountValue ?? 0);
    setDReason(item?.discountReason ?? "");
  };
  const applyDiscount = () => {
    if (!discountFor) return;
    setCart((c) =>
      c.map((i) => {
        if (i.productId !== discountFor) return i;
        const lineTotal = i.price * i.qty;
        const amount = dType === "rs" ? Math.min(dValue, lineTotal) : Math.min((dValue / 100) * lineTotal, lineTotal);
        return { ...i, discountType: dType, discountValue: dValue, discountAmount: amount, discountReason: dReason };
      })
    );
    setDiscountFor(null);
    toast.success("Discount applied");
  };

  const lookupCustomer = () => {
    const c = customers.find((x) => x.phone === customerPhone);
    if (c) {
      setCustomerName(c.name); setCustomerAddress(c.address); setDeliveryCharge(c.deliveryCharge);
      toast.success("Customer found: " + c.name);
    } else toast.info("New customer — fill details");
  };

  const finalize = (asOngoing: boolean) => {
    if (cart.length === 0) return toast.error("Cart is empty");
    if (orderType === "dine-in" && !tableId) return toast.error("Pick a table");
    if (orderType === "delivery" && (!customerName || !customerPhone)) return toast.error("Customer name & phone required");
    if (!asOngoing && payMethod === "online" && !senderPhone.trim())
      return toast.error("Sender phone number is required for wallet transfer");
    if (!asOngoing && payMethod === "online" && !txnId.trim())
      return toast.error("Transaction ID is required for online payment");

    const order = createOrder({
      items: cart,
      type: orderType,
      cashier: username ?? "staff",
      tableId: orderType === "dine-in" ? tableId : undefined,
      customer: orderType === "delivery" ? { name: customerName, phone: customerPhone, address: customerAddress, deliveryCharge } : undefined,
      paymentMethod: asOngoing ? undefined : payMethod,
      walletProvider: !asOngoing && payMethod === "online" ? walletProvider : undefined,
      senderPhone: !asOngoing && payMethod === "online" ? senderPhone.trim() : undefined,
      transactionId: !asOngoing && payMethod === "online" ? txnId.trim() : undefined,
      paymentRef: !asOngoing && payMethod === "online" ? payRef.trim() : undefined,
      creditCustomerName: payMethod === "credit" ? creditName || customerName || undefined : undefined,
      notes,
    });

    // Auto-print kitchen ticket
    const html = renderToString(<ReceiptHTML order={order} settings={printer} kind="kitchen" />);
    if (printer.autoPrint) browserPrint(html);
    toast.success(`Order ${order.shortId} ${asOngoing ? "sent to kitchen" : "completed & paid"}`);
    setPayOpen(false); clearCart();
    setSenderPhone(""); setTxnId(""); setPayRef(""); setCreditName("");
  };

  const printBill = () => {
    if (cart.length === 0) return toast.error("Cart is empty");
    const tempOrder = {
      id: "preview", shortId: "PREVIEW",
      items: cart, subtotal, discountTotal,
      deliveryCharge: orderType === "delivery" ? deliveryCharge : 0,
      total, type: orderType, status: "ongoing" as const,
      tableId, customerName, customerPhone, customerAddress,
      cashier: username ?? "staff", createdAt: Date.now(),
    };
    const html = renderToString(<ReceiptHTML order={tempOrder as any} settings={printer} kind="bill" />);
    browserPrint(html);
  };

  const tryThermal = async () => {
    try {
      const tempOrder = {
        id: "preview", shortId: "PREVIEW",
        items: cart, subtotal, discountTotal,
        deliveryCharge: orderType === "delivery" ? deliveryCharge : 0,
        total, type: orderType, status: "ongoing" as const,
        tableId, customerName, customerPhone, customerAddress,
        cashier: username ?? "staff", createdAt: Date.now(),
      };
      await printText(buildReceiptText(tempOrder as any, printer, "bill"));
      toast.success("Sent to thermal printer");
    } catch (e: any) {
      toast.error(e.message ?? "Printer error");
    }
  };

  return (
    <RoleShell title="Cashier Station" accent="primary" nav={STAFF_NAV}>
      <div className="grid lg:grid-cols-[1fr_420px] h-[calc(100vh-110px)]">
        {/* Products panel */}
        <div className="flex flex-col min-h-0 border-r">
          <div className="p-4 border-b bg-card">
            <div className="flex gap-3 items-center">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search products…" className="pl-9 h-11" />
              </div>
              <Link to="/staff/ongoing">
                <Button variant="outline" className="h-11"><Receipt className="w-4 h-4 mr-1" /> Ongoing</Button>
              </Link>
            </div>
            <Tabs value={activeCat} onValueChange={setActiveCat} className="mt-3">
              <TabsList className="bg-muted h-11 overflow-x-auto w-full justify-start scrollbar-thin">
                <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">All</TabsTrigger>
                {categories.map((c) => (
                  <TabsTrigger key={c.id} value={c.id} className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                    <span className="mr-1">{c.emoji}</span>{c.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
          <div className="flex-1 overflow-auto p-4 scrollbar-thin">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {filtered.map((p) => (
                <button
                  key={p.id}
                  onClick={() => addToCart(p.id)}
                  className="group rounded-xl bg-card border-2 border-border hover:border-primary hover:shadow-glow transition-all p-4 text-left active:scale-[0.97] animate-fade-in"
                >
                  <div className="text-4xl mb-2">{p.emoji}</div>
                  <div className="font-semibold text-sm leading-tight line-clamp-2 min-h-[2.5rem]">{p.name}</div>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="font-display text-xl text-primary">{fmt(p.price)}</span>
                    <span className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                      <Plus className="w-4 h-4" />
                    </span>
                  </div>
                </button>
              ))}
              {filtered.length === 0 && (
                <div className="col-span-full text-center text-muted-foreground py-20">No items match your search.</div>
              )}
            </div>
          </div>
        </div>

        {/* Cart panel */}
        <div className="flex flex-col min-h-0 bg-secondary text-secondary-foreground">
          <div className="p-4 border-b border-secondary-foreground/10">
            <div className="flex items-center gap-2 mb-3">
              <ShoppingCart className="w-5 h-5 text-primary" />
              <h3 className="font-display text-2xl">Current Order</h3>
              <Badge className="ml-auto bg-primary text-primary-foreground">{cart.reduce((a, i) => a + i.qty, 0)} items</Badge>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {([
                { v: "dine-in", l: "Dine-In", icon: UtensilsCrossed },
                { v: "takeaway", l: "Takeaway", icon: ShoppingBag },
                { v: "delivery", l: "Delivery", icon: Bike },
              ] as const).map((o) => {
                const Icon = o.icon;
                return (
                  <button key={o.v} onClick={() => setOrderType(o.v)}
                    className={cn("flex flex-col items-center py-2 rounded-md text-xs font-medium transition",
                      orderType === o.v ? "bg-primary text-primary-foreground" : "bg-secondary-foreground/10 hover:bg-secondary-foreground/20")}>
                    <Icon className="w-4 h-4 mb-1" />{o.l}
                  </button>
                );
              })}
            </div>

            {orderType === "dine-in" && (
              <div className="mt-3">
                <Label className="text-xs uppercase tracking-wider text-secondary-foreground/60">Table</Label>
                <div className="grid grid-cols-6 gap-1.5 mt-1.5">
                  {tables.map((t) => (
                    <button key={t.id} onClick={() => setTableId(t.id)} disabled={t.status === "busy" && t.id !== tableId}
                      className={cn("h-9 rounded-md text-sm font-semibold transition",
                        tableId === t.id ? "bg-primary text-primary-foreground" :
                        t.status === "busy" ? "bg-destructive/30 text-destructive-foreground/50 cursor-not-allowed" :
                        "bg-secondary-foreground/10 hover:bg-secondary-foreground/20")}>
                      {t.number}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {orderType === "delivery" && (
              <div className="mt-3 space-y-2">
                <div className="flex gap-2">
                  <Input placeholder="Phone" value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)}
                    className="bg-secondary-foreground/10 border-secondary-foreground/20 text-secondary-foreground placeholder:text-secondary-foreground/40" />
                  <Button size="sm" variant="secondary" onClick={lookupCustomer}>Lookup</Button>
                </div>
                <Input placeholder="Name" value={customerName} onChange={(e) => setCustomerName(e.target.value)}
                  className="bg-secondary-foreground/10 border-secondary-foreground/20 text-secondary-foreground placeholder:text-secondary-foreground/40" />
                <Input placeholder="Address" value={customerAddress} onChange={(e) => setCustomerAddress(e.target.value)}
                  className="bg-secondary-foreground/10 border-secondary-foreground/20 text-secondary-foreground placeholder:text-secondary-foreground/40" />
                <Input type="number" placeholder="Delivery charge (Rs.)" value={deliveryCharge || ""}
                  onChange={(e) => setDeliveryCharge(Number(e.target.value) || 0)}
                  className="bg-secondary-foreground/10 border-secondary-foreground/20 text-secondary-foreground placeholder:text-secondary-foreground/40" />
              </div>
            )}
          </div>

          <div className="flex-1 overflow-auto p-3 space-y-2 scrollbar-thin">
            {cart.length === 0 && (
              <div className="text-center text-secondary-foreground/50 py-16">
                <ShoppingCart className="w-12 h-12 mx-auto mb-3 opacity-30" />
                Tap items to add them to the order.
              </div>
            )}
            {cart.map((it) => (
              <div key={it.productId} className="bg-secondary-foreground/5 rounded-lg p-3 animate-slide-in-right">
                <div className="flex items-start gap-2">
                  <span className="text-2xl">{it.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-sm leading-tight">{it.name}</div>
                    <div className="text-xs text-secondary-foreground/60">{fmt(it.price)} each</div>
                    {it.discountAmount ? (
                      <div className="text-xs text-accent font-medium mt-0.5">
                        − {fmt(it.discountAmount)} {it.discountReason ? `· ${it.discountReason}` : ""}
                      </div>
                    ) : null}
                  </div>
                  <div className="text-right">
                    <div className="font-display text-lg text-primary">{fmt(it.price * it.qty - (it.discountAmount ?? 0))}</div>
                  </div>
                </div>
                <div className="flex items-center gap-1 mt-2">
                  <Button size="icon" variant="ghost" className="h-7 w-7 text-secondary-foreground hover:bg-secondary-foreground/10" onClick={() => setQty(it.productId, it.qty - 1)}><Minus className="w-3.5 h-3.5" /></Button>
                  <span className="w-8 text-center font-semibold">{it.qty}</span>
                  <Button size="icon" variant="ghost" className="h-7 w-7 text-secondary-foreground hover:bg-secondary-foreground/10" onClick={() => setQty(it.productId, it.qty + 1)}><Plus className="w-3.5 h-3.5" /></Button>
                  <Button size="sm" variant="ghost" className="ml-auto h-7 px-2 text-accent hover:bg-accent/10" onClick={() => openDiscount(it.productId)}><Tag className="w-3.5 h-3.5 mr-1" />Discount</Button>
                  <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive hover:bg-destructive/10" onClick={() => removeFromCart(it.productId)}><Trash2 className="w-3.5 h-3.5" /></Button>
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 border-t border-secondary-foreground/10 space-y-2">
            <Textarea placeholder="Order notes (optional)" value={notes} onChange={(e) => setNotes(e.target.value)}
              className="bg-secondary-foreground/10 border-secondary-foreground/20 text-secondary-foreground placeholder:text-secondary-foreground/40 min-h-[60px]" />
            <div className="space-y-1 text-sm">
              <div className="flex justify-between"><span className="text-secondary-foreground/60">Subtotal</span><span className="font-mono">{fmt(subtotal)}</span></div>
              {discountTotal > 0 && <div className="flex justify-between text-accent"><span>Discount</span><span className="font-mono">− {fmt(discountTotal)}</span></div>}
              {orderType === "delivery" && deliveryCharge > 0 && <div className="flex justify-between"><span className="text-secondary-foreground/60">Delivery</span><span className="font-mono">{fmt(deliveryCharge)}</span></div>}
              <div className="flex justify-between text-2xl font-display border-t border-secondary-foreground/10 pt-2 mt-1">
                <span>TOTAL</span><span className="text-primary">{fmt(total)}</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <Button variant="outline" className="border-secondary-foreground/20 text-secondary-foreground hover:bg-secondary-foreground/10" onClick={printBill}>
                <Printer className="w-4 h-4 mr-1" /> Print Bill
              </Button>
              <Button variant="outline" className="border-secondary-foreground/20 text-secondary-foreground hover:bg-secondary-foreground/10" onClick={() => finalize(true)}>
                <Receipt className="w-4 h-4 mr-1" /> Send to Kitchen
              </Button>
            </div>
            <Button size="lg" className="w-full h-12 bg-gradient-primary hover:opacity-95 shadow-glow" onClick={() => setPayOpen(true)}>
              <Wallet className="w-5 h-5 mr-2" /> Pay & Complete
            </Button>
            <Button variant="ghost" size="sm" className="w-full text-secondary-foreground/60 hover:bg-destructive/20 hover:text-destructive-foreground" onClick={clearCart}>
              <X className="w-3.5 h-3.5 mr-1" /> Clear Order
            </Button>
            <Button variant="ghost" size="sm" className="w-full text-secondary-foreground/40 text-xs" onClick={tryThermal}>
              <Printer className="w-3 h-3 mr-1" /> Try thermal print (Bluetooth)
            </Button>
          </div>
        </div>
      </div>

      {/* Discount dialog */}
      <Dialog open={!!discountFor} onOpenChange={(v) => !v && setDiscountFor(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Apply Discount</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <RadioGroup value={dType} onValueChange={(v) => setDType(v as any)} className="grid grid-cols-2 gap-2">
              <label className={cn("flex items-center gap-2 border rounded-md p-3 cursor-pointer", dType === "rs" && "border-primary bg-primary/5")}>
                <RadioGroupItem value="rs" /> Flat (Rs.)
              </label>
              <label className={cn("flex items-center gap-2 border rounded-md p-3 cursor-pointer", dType === "pct" && "border-primary bg-primary/5")}>
                <RadioGroupItem value="pct" /> Percent (%)
              </label>
            </RadioGroup>
            <div>
              <Label>Value</Label>
              <Input type="number" value={dValue || ""} onChange={(e) => setDValue(Number(e.target.value) || 0)} />
            </div>
            <div>
              <Label>Reason</Label>
              <Input value={dReason} onChange={(e) => setDReason(e.target.value)} placeholder="e.g. loyalty, manager comp" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setDiscountFor(null)}>Cancel</Button>
            <Button onClick={applyDiscount} className="bg-gradient-primary"><Check className="w-4 h-4 mr-1" />Apply</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payment dialog */}
      <Dialog open={payOpen} onOpenChange={setPayOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Choose Payment Method</DialogTitle></DialogHeader>
          <div className="text-3xl font-display text-primary text-center py-2">{fmt(total)}</div>
          <div className="grid grid-cols-2 gap-2">
            {([
              { v: "cash", l: "Cash", icon: Banknote },
              { v: "card", l: "Card", icon: CreditCard },
              { v: "online", l: "Online", icon: Smartphone },
              { v: "credit", l: "Credit", icon: Wallet },
            ] as const).map((m) => {
              const Icon = m.icon;
              return (
                <button key={m.v} onClick={() => setPayMethod(m.v)}
                  className={cn("p-4 rounded-lg border-2 flex flex-col items-center gap-1 transition",
                    payMethod === m.v ? "border-primary bg-primary/5 shadow-glow" : "border-border hover:border-primary/40")}>
                  <Icon className="w-6 h-6" /><span className="font-semibold">{m.l}</span>
                </button>
              );
            })}
          </div>
          {payMethod === "online" && (
            <div className="space-y-3 animate-fade-in border-t pt-3">
              <div>
                <Label className="text-xs uppercase tracking-wider text-muted-foreground">Wallet / Transfer Provider</Label>
                <div className="grid grid-cols-3 gap-2 mt-1.5">
                  {WALLET_PROVIDERS.map((w) => (
                    <button key={w.value} type="button" onClick={() => setWalletProvider(w.value)}
                      className={cn("p-2.5 rounded-md border-2 flex flex-col items-center gap-0.5 text-xs font-medium transition",
                        walletProvider === w.value ? "border-primary bg-primary/5 shadow-glow" : "border-border hover:border-primary/40")}>
                      <span className="text-xl">{w.emoji}</span>
                      <span className="leading-tight text-center">{w.label}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>Sender Phone <span className="text-destructive">*</span></Label>
                  <Input inputMode="tel" value={senderPhone} onChange={(e) => setSenderPhone(e.target.value)} placeholder="03XX-XXXXXXX" maxLength={20} />
                </div>
                <div>
                  <Label>Transaction ID <span className="text-destructive">*</span></Label>
                  <Input value={txnId} onChange={(e) => setTxnId(e.target.value)} placeholder="TID / Ref #" maxLength={40} />
                </div>
              </div>
              <div>
                <Label>Note (optional)</Label>
                <Input value={payRef} onChange={(e) => setPayRef(e.target.value)} placeholder="e.g. account name, last 4" maxLength={60} />
              </div>
            </div>
          )}
          {payMethod === "credit" && (
            <div className="animate-fade-in">
              <Label>Credit customer name</Label>
              <Input value={creditName} onChange={(e) => setCreditName(e.target.value)} placeholder="Will appear in Credit Sale" />
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setPayOpen(false)}>Cancel</Button>
            <Button onClick={() => finalize(false)} className="bg-gradient-primary">Confirm & Print</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </RoleShell>
  );
};

export default Staff;
