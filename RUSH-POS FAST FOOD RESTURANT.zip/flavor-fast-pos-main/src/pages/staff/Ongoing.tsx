import { RoleShell } from "@/components/RoleShell";
import { usePOS } from "@/store/pos";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { Printer, Check, Trash2, Receipt as ReceiptIcon, X } from "lucide-react";
import { fmt } from "@/lib/format";
import { toast } from "sonner";
import { browserPrint } from "@/lib/printing";
import { ReceiptHTML } from "@/components/ReceiptHTML";
import { renderToString } from "react-dom/server";
import { format } from "date-fns";

const STAFF_NAV = [
  { to: "/staff", label: "POS" },
  { to: "/staff/ongoing", label: "Ongoing" },
  { to: "/staff/tables", label: "Tables" },
  { to: "/staff/customers", label: "Delivery Book" },
];

const Ongoing = () => {
  const { orders, printer, deleteOrder, markReceived } = usePOS();
  const [delId, setDelId] = useState<string | null>(null);
  const [reason, setReason] = useState("");

  const ongoing = orders.filter((o) => ["ongoing", "received", "ready"].includes(o.status));

  const print = (id: string, kind: "bill" | "kitchen") => {
    const o = orders.find((x) => x.id === id);
    if (!o) return;
    const html = renderToString(<ReceiptHTML order={o} settings={printer} kind={kind} />);
    browserPrint(html);
  };

  return (
    <RoleShell title="Ongoing Orders" accent="primary" nav={STAFF_NAV}>
      <div className="p-4 md:p-6 max-w-7xl mx-auto">
        <h2 className="font-display text-3xl mb-4">Ongoing Orders <Badge className="ml-2 bg-primary">{ongoing.length}</Badge></h2>
        {ongoing.length === 0 && (
          <div className="text-center py-20 text-muted-foreground border border-dashed rounded-lg">
            <ReceiptIcon className="w-12 h-12 mx-auto opacity-30 mb-3" />
            No ongoing orders. New ones will appear here.
          </div>
        )}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {ongoing.map((o) => (
            <Card key={o.id} className="p-4 shadow-card animate-fade-in border-l-4"
              style={{ borderLeftColor: o.status === "ready" ? "hsl(var(--success))" : o.status === "received" ? "hsl(var(--accent))" : "hsl(var(--primary))" }}>
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="font-display text-2xl">{o.shortId}</div>
                  <div className="text-xs text-muted-foreground">{format(o.createdAt, "HH:mm")} · {o.cashier}</div>
                </div>
                <Badge variant="secondary" className="capitalize">{o.type.replace("-", " ")}</Badge>
              </div>
              <div className="flex items-center gap-2 mb-2">
                <Badge className={
                  o.status === "ready" ? "bg-success text-success-foreground" :
                  o.status === "received" ? "bg-accent text-accent-foreground" : "bg-primary"
                }>{o.status}</Badge>
                {o.tableId && <span className="text-xs text-muted-foreground">Table {o.tableId}</span>}
                {o.customerName && <span className="text-xs text-muted-foreground truncate">{o.customerName}</span>}
              </div>
              <ul className="text-sm space-y-0.5 mb-3 max-h-32 overflow-auto scrollbar-thin">
                {o.items.map((i) => <li key={i.productId} className="flex justify-between"><span>{i.qty}× {i.name}</span><span className="font-mono text-xs">{fmt(i.price * i.qty)}</span></li>)}
              </ul>
              <div className="flex justify-between font-display text-xl border-t pt-2"><span>Total</span><span className="text-primary">{fmt(o.total)}</span></div>
              <div className="flex flex-wrap gap-1.5 mt-3">
                <Button size="sm" variant="outline" onClick={() => print(o.id, "bill")}><Printer className="w-3 h-3 mr-1" />Bill</Button>
                <Button size="sm" variant="outline" onClick={() => print(o.id, "kitchen")}><Printer className="w-3 h-3 mr-1" />Kitchen</Button>
                {o.status === "ongoing" && <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90" onClick={() => { markReceived(o.id); toast.success("Marked received"); }}><Check className="w-3 h-3 mr-1" />Received</Button>}
                <Button size="sm" variant="ghost" className="text-destructive hover:bg-destructive/10 ml-auto" onClick={() => setDelId(o.id)}><Trash2 className="w-3 h-3" /></Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
      <Dialog open={!!delId} onOpenChange={(v) => !v && setDelId(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Delete order?</DialogTitle></DialogHeader>
          <Label>Reason (required for audit log)</Label>
          <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. customer cancelled" />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setDelId(null)}>Keep</Button>
            <Button variant="destructive" onClick={() => { if (!reason.trim()) return toast.error("Reason required"); deleteOrder(delId!, reason); setDelId(null); setReason(""); toast.success("Order deleted"); }}>
              <X className="w-4 h-4 mr-1" /> Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </RoleShell>
  );
};

export default Ongoing;
