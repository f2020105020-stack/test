import { RoleShell } from "@/components/RoleShell";
import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { fmt } from "@/lib/format";

const STAFF_NAV = [
  { to: "/staff", label: "POS" },
  { to: "/staff/ongoing", label: "Ongoing" },
  { to: "/staff/tables", label: "Tables" },
  { to: "/staff/customers", label: "Delivery Book" },
];

const Tables = () => {
  const { tables, orders, freeTable } = usePOS();

  return (
    <RoleShell title="Tables" accent="primary" nav={STAFF_NAV}>
      <div className="p-4 md:p-6 max-w-6xl mx-auto">
        <h2 className="font-display text-3xl mb-1">Floor Plan</h2>
        <p className="text-sm text-muted-foreground mb-6">Tap a busy table to view its order. Use <em>Force Free</em> only after settling.</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {tables.map((t) => {
            const order = orders.find((o) => o.id === t.currentOrderId);
            return (
              <Card key={t.id} className={cn("p-5 transition-all", t.status === "busy" ? "border-primary border-2 shadow-glow" : "border-success/40 bg-success/5")}>
                <div className="flex items-center justify-between">
                  <span className="font-display text-4xl">{t.number}</span>
                  <Badge className={t.status === "busy" ? "bg-primary" : "bg-success text-success-foreground"}>{t.status}</Badge>
                </div>
                <div className="text-sm text-muted-foreground mt-1 flex items-center gap-1"><Users className="w-3 h-3" /> Seats {t.capacity}</div>
                {order ? (
                  <div className="mt-3 space-y-1 border-t pt-2">
                    <div className="text-xs"><strong>{order.shortId}</strong> · {order.items.length} items</div>
                    <div className="font-display text-lg text-primary">{fmt(order.total)}</div>
                    <Button size="sm" variant="outline" className="w-full mt-2 text-destructive border-destructive/40 hover:bg-destructive/10" onClick={() => freeTable(t.id)}>
                      <AlertTriangle className="w-3 h-3 mr-1" /> Force Free
                    </Button>
                  </div>
                ) : (
                  <div className="text-xs text-success/80 mt-3 border-t pt-2">Available</div>
                )}
              </Card>
            );
          })}
        </div>
      </div>
    </RoleShell>
  );
};

export default Tables;
