import { Routes, Route, Navigate } from "react-router-dom";
import { RoleShell } from "@/components/RoleShell";
import Dashboard from "./admin/Dashboard";
import SaleHistory from "./admin/SaleHistory";
import OnlinePayments from "./admin/OnlinePayments";
import CreditSale from "./admin/CreditSale";
import DeletedOrders from "./admin/DeletedOrders";
import MonthlyReport from "./admin/MonthlyReport";
import DiscountReport from "./admin/DiscountReport";
import DeliveryDB from "./admin/DeliveryDB";
import Products from "./admin/Products";
import Categories from "./admin/Categories";
import TablesAdmin from "./admin/TablesAdmin";
import PrinterPage from "./admin/PrinterPage";
import Backup from "./admin/Backup";

const ADMIN_NAV = [
  { to: "/admin", label: "Dashboard" },
  { to: "/admin/sales", label: "Sale History" },
  { to: "/admin/online", label: "Online" },
  { to: "/admin/credit", label: "Credit" },
  { to: "/admin/deleted", label: "Deleted" },
  { to: "/admin/monthly", label: "Monthly" },
  { to: "/admin/discounts", label: "Discounts" },
  { to: "/admin/delivery", label: "Delivery DB" },
  { to: "/admin/products", label: "Products" },
  { to: "/admin/categories", label: "Categories" },
  { to: "/admin/tables", label: "Tables" },
  { to: "/admin/printer", label: "Printer" },
  { to: "/admin/backup", label: "Backup" },
];

const AdminLayout = ({ children }: { children: React.ReactNode }) => (
  <RoleShell title="Admin Panel" accent="secondary" nav={ADMIN_NAV}>
    <div className="p-4 md:p-6 max-w-7xl mx-auto">{children}</div>
  </RoleShell>
);

const Admin = () => (
  <Routes>
    <Route index element={<AdminLayout><Dashboard /></AdminLayout>} />
    <Route path="sales" element={<AdminLayout><SaleHistory /></AdminLayout>} />
    <Route path="online" element={<AdminLayout><OnlinePayments /></AdminLayout>} />
    <Route path="credit" element={<AdminLayout><CreditSale /></AdminLayout>} />
    <Route path="deleted" element={<AdminLayout><DeletedOrders /></AdminLayout>} />
    <Route path="monthly" element={<AdminLayout><MonthlyReport /></AdminLayout>} />
    <Route path="discounts" element={<AdminLayout><DiscountReport /></AdminLayout>} />
    <Route path="delivery" element={<AdminLayout><DeliveryDB /></AdminLayout>} />
    <Route path="products" element={<AdminLayout><Products /></AdminLayout>} />
    <Route path="categories" element={<AdminLayout><Categories /></AdminLayout>} />
    <Route path="tables" element={<AdminLayout><TablesAdmin /></AdminLayout>} />
    <Route path="printer" element={<AdminLayout><PrinterPage /></AdminLayout>} />
    <Route path="backup" element={<AdminLayout><Backup /></AdminLayout>} />
    <Route path="*" element={<Navigate to="/admin" replace />} />
  </Routes>
);

export default Admin;
