import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { fmt } from "@/lib/format";
import { format } from "date-fns";
import { Plus, Trash2, Pencil, Phone, MapPin } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const empty = { name: "", phone: "", address: "", deliveryCharge: 100 };

const DeliveryDB = () => {
  const { customers, upsertCustomer, deleteCustomer, orders } = usePOS();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);

  const submit = () => {
    if (!form.name || !form.phone) return toast.error("Name & phone required");
    upsertCustomer(form);
    toast.success("Saved");
    setOpen(false); setForm(empty);
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-4xl">Delivery Customer Database</h2>
        <Button onClick={() => { setForm(empty); setOpen(true); }} className="bg-gradient-primary"><Plus className="w-4 h-4 mr-1" />Add</Button>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {customers.map((c) => {
          const history = orders.filter((o) => o.customerPhone === c.phone);
          return (
            <Card key={c.id} className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-semibold text-lg">{c.name}</div>
                  <div className="text-sm text-muted-foreground flex items-center gap-1"><Phone className="w-3 h-3" />{c.phone}</div>
                  <div className="text-sm text-muted-foreground flex items-start gap-1 mt-1"><MapPin className="w-3 h-3 mt-0.5" />{c.address}</div>
                </div>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => { setForm(c); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" className="text-destructive" onClick={() => deleteCustomer(c.id)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t text-center text-xs">
                <div><div className="font-display text-xl text-primary">{c.totalOrders}</div><div className="text-muted-foreground">Orders</div></div>
                <div><div className="font-display text-xl">{fmt(c.totalRevenue)}</div><div className="text-muted-foreground">Revenue</div></div>
                <div><div className="font-display text-xl">{fmt(c.deliveryCharge)}</div><div className="text-muted-foreground">Delivery</div></div>
              </div>
              {history.length > 0 && (
                <details className="mt-2 text-xs"><summary className="cursor-pointer text-primary">{history.length} order(s)</summary>
                  <ul className="mt-2 space-y-1 max-h-32 overflow-auto">
                    {history.map((h) => <li key={h.id} className="flex justify-between"><span>{h.shortId} · {format(h.createdAt, "MMM d")}</span><span className="font-mono">{fmt(h.total)}</span></li>)}
                  </ul>
                </details>
              )}
            </Card>
          );
        })}
        {customers.length === 0 && <div className="col-span-full text-center py-16 text-muted-foreground border border-dashed rounded-lg">No customers in DB.</div>}
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Customer Details</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div><Label>Address</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div><Label>Default Delivery Charge (Rs.)</Label><Input type="number" value={form.deliveryCharge} onChange={(e) => setForm({ ...form, deliveryCharge: Number(e.target.value) })} /></div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={submit} className="bg-gradient-primary">Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
export default DeliveryDB;
