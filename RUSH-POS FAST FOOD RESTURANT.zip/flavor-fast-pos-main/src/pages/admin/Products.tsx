import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { useState } from "react";
import { fmt } from "@/lib/format";
import { toast } from "sonner";
import { Product } from "@/types/pos";

const empty = { name: "", price: 0, categoryId: "", emoji: "🍔", available: true };

const Products = () => {
  const { products, categories, addProduct, updateProduct, deleteProduct } = usePOS();
  const [open, setOpen] = useState(false);
  const [edit, setEdit] = useState<Product | null>(null);
  const [form, setForm] = useState<typeof empty>(empty);

  const save = () => {
    if (!form.name || !form.categoryId) return toast.error("Name & category required");
    if (edit) updateProduct(edit.id, form);
    else addProduct(form);
    toast.success("Saved");
    setOpen(false); setEdit(null);
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-4xl">Products</h2>
        <Button onClick={() => { setEdit(null); setForm({ ...empty, categoryId: categories[0]?.id ?? "" }); setOpen(true); }} className="bg-gradient-primary"><Plus className="w-4 h-4 mr-1" />Add Product</Button>
      </div>
      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-secondary-foreground">
            <tr><th className="p-3 text-left">Item</th><th className="p-3 text-left">Category</th><th className="p-3 text-right">Price</th><th className="p-3 text-center">Available</th><th className="p-3 text-right"></th></tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-t">
                <td className="p-3"><span className="text-2xl mr-2">{p.emoji}</span>{p.name}</td>
                <td className="p-3">{categories.find((c) => c.id === p.categoryId)?.name}</td>
                <td className="p-3 text-right font-mono">{fmt(p.price)}</td>
                <td className="p-3 text-center"><Switch checked={p.available} onCheckedChange={(v) => updateProduct(p.id, { available: v })} /></td>
                <td className="p-3 text-right">
                  <Button size="icon" variant="ghost" onClick={() => { setEdit(p); setForm(p); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" className="text-destructive" onClick={() => { if (confirm("Delete?")) deleteProduct(p.id); }}><Trash2 className="w-4 h-4" /></Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{edit ? "Edit" : "Add"} Product</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Price (Rs.)</Label><Input type="number" value={form.price || ""} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} /></div>
              <div><Label>Emoji</Label><Input value={form.emoji} onChange={(e) => setForm({ ...form, emoji: e.target.value })} maxLength={2} /></div>
            </div>
            <div><Label>Category</Label>
              <select className="w-full h-10 border rounded-md px-3 bg-background" value={form.categoryId} onChange={(e) => setForm({ ...form, categoryId: e.target.value })}>
                <option value="">Choose…</option>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.emoji} {c.name}</option>)}
              </select>
            </div>
            <label className="flex items-center gap-2"><Switch checked={form.available} onCheckedChange={(v) => setForm({ ...form, available: v })} /> Available</label>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save} className="bg-gradient-primary">Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
export default Products;
