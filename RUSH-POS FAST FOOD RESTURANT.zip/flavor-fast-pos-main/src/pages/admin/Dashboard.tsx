import { Card } from "@/components/ui/card";
import { usePOS } from "@/store/pos";
import { fmt } from "@/lib/format";
import { TrendingUp, ShoppingBag, Wallet, Bike, AlertTriangle, Tag, Trash2, CreditCard, Banknote, Smartphone, Receipt } from "lucide-react";
import { startOfDay, endOfDay, subDays, isWithinInterval, startOfMonth, endOfMonth } from "date-fns";

const StatCard = ({ icon: Icon, label, value, sub, color = "primary" }: any) => (
  <Card className="p-5 shadow-card">
    <div className="flex items-start justify-between">
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="font-display text-3xl mt-1">{value}</div>
        {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
      </div>
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center bg-${color}/10 text-${color}`}>
        <Icon className="w-5 h-5" />
      </div>
    </div>
  </Card>
);

const Dashboard = () => {
  const { orders, customers } = usePOS();
  const now = Date.now();
  const today = orders.filter((o) => isWithinInterval(o.createdAt, { start: startOfDay(now), end: endOfDay(now) }) && o.status === "paid");
  const yesterday = orders.filter((o) => isWithinInterval(o.createdAt, { start: startOfDay(subDays(now, 1)), end: endOfDay(subDays(now, 1)) }) && o.status === "paid");
  const month = orders.filter((o) => isWithinInterval(o.createdAt, { start: startOfMonth(now), end: endOfMonth(now) }) && o.status === "paid");
  const ongoing = orders.filter((o) => ["ongoing", "received", "ready"].includes(o.status));
  const credit = orders.filter((o) => o.status === "credit");
  const settled = orders.filter((o) => o.creditSettledAt);
  const deleted = orders.filter((o) => o.status === "deleted");

  const sumByMethod = (m: string) => orders.filter((o) => o.status === "paid" && o.paymentMethod === m).reduce((a, o) => a + o.total, 0);
  const totalDiscount = orders.reduce((a, o) => a + o.discountTotal, 0);
  const todayRev = today.reduce((a, o) => a + o.total, 0);
  const yRev = yesterday.reduce((a, o) => a + o.total, 0);
  const monthRev = month.reduce((a, o) => a + o.total, 0);
  const avg = today.length ? todayRev / today.length : 0;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="font-display text-4xl">Dashboard</h2>
        <p className="text-muted-foreground">Real-time snapshot of operations.</p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={TrendingUp} label="Today's Sales" value={fmt(todayRev)} sub={`${today.length} orders · avg ${fmt(avg)}`} color="primary" />
        <StatCard icon={Receipt} label="Yesterday" value={fmt(yRev)} sub={`${yesterday.length} orders`} color="accent" />
        <StatCard icon={ShoppingBag} label="This Month" value={fmt(monthRev)} sub={`${month.length} orders`} color="success" />
        <StatCard icon={AlertTriangle} label="Ongoing" value={ongoing.length} sub={`${customers.length} customers in DB`} color="warning" />
      </div>

      <div>
        <h3 className="font-display text-2xl mb-3">Payment Methods (all-time)</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <StatCard icon={Banknote} label="Cash" value={fmt(sumByMethod("cash"))} color="success" />
          <StatCard icon={CreditCard} label="Card" value={fmt(sumByMethod("card"))} color="primary" />
          <StatCard icon={Smartphone} label="Online" value={fmt(sumByMethod("online"))} color="accent" />
          <StatCard icon={Wallet} label="Credit (settled)" value={fmt(settled.reduce((a, o) => a + o.total, 0))} sub={`${settled.length} settled`} color="secondary" />
        </div>
      </div>

      <div>
        <h3 className="font-display text-2xl mb-3">Operations</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <StatCard icon={Wallet} label="Outstanding Credit" value={fmt(credit.reduce((a, o) => a + o.total, 0))} sub={`${credit.length} unpaid`} color="destructive" />
          <StatCard icon={Tag} label="Total Discounts" value={fmt(totalDiscount)} color="accent" />
          <StatCard icon={Trash2} label="Deleted Orders" value={deleted.length} color="destructive" />
          <StatCard icon={Bike} label="Delivery Customers" value={customers.length} color="primary" />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
