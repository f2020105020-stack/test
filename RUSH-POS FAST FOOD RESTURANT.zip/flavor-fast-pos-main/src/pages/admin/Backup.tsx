import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Upload, RotateCcw, FileSpreadsheet } from "lucide-react";
import { toast } from "sonner";
import { useRef } from "react";
import { format } from "date-fns";
import { fmt } from "@/lib/format";

const Backup = () => {
  const { exportAll, importAll, resetAll, orders } = usePOS();
  const fileRef = useRef<HTMLInputElement>(null);

  const exportJSON = () => {
    const blob = new Blob([exportAll()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `rush-backup-${format(Date.now(), "yyyyMMdd-HHmm")}.json`;
    a.click(); URL.revokeObjectURL(url);
    toast.success("Backup downloaded");
  };

  const exportCSV = () => {
    const headers = ["Order ID", "Date", "Type", "Status", "Method", "Customer", "Phone", "Subtotal", "Discount", "Delivery", "Total", "Cashier"];
    const rows = orders.map((o) => [o.shortId, format(o.createdAt, "yyyy-MM-dd HH:mm"), o.type, o.status, o.paymentMethod ?? "", o.customerName ?? "", o.customerPhone ?? "",
      o.subtotal, o.discountTotal, o.deliveryCharge, o.total, o.cashier]);
    const csv = [headers, ...rows].map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `rush-orders-${format(Date.now(), "yyyyMMdd")}.csv`;
    a.click(); URL.revokeObjectURL(url);
    toast.success("CSV downloaded");
  };

  const importJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try { importAll(String(reader.result)); toast.success("Restored"); }
      catch { toast.error("Invalid backup file"); }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-4 animate-fade-in max-w-3xl">
      <h2 className="font-display text-4xl">Backup & Data</h2>
      <p className="text-muted-foreground">All data is stored in this browser's local storage. Export regularly!</p>
      <div className="grid sm:grid-cols-2 gap-3">
        <Card className="p-5 space-y-2">
          <div className="font-semibold flex items-center gap-2"><Download className="w-4 h-4" /> Export Full Backup (JSON)</div>
          <p className="text-xs text-muted-foreground">Includes products, orders, customers, tables, and settings.</p>
          <Button onClick={exportJSON} className="bg-gradient-primary w-full"><Download className="w-4 h-4 mr-1" />Download JSON</Button>
        </Card>
        <Card className="p-5 space-y-2">
          <div className="font-semibold flex items-center gap-2"><FileSpreadsheet className="w-4 h-4" /> Export Orders (CSV)</div>
          <p className="text-xs text-muted-foreground">Open in Excel / Google Sheets. {orders.length} orders.</p>
          <Button onClick={exportCSV} variant="outline" className="w-full"><Download className="w-4 h-4 mr-1" />Download CSV</Button>
        </Card>
        <Card className="p-5 space-y-2">
          <div className="font-semibold flex items-center gap-2"><Upload className="w-4 h-4" /> Restore from Backup</div>
          <p className="text-xs text-muted-foreground">⚠️ Replaces all current data.</p>
          <input ref={fileRef} type="file" accept="application/json" hidden onChange={importJSON} />
          <Button onClick={() => fileRef.current?.click()} variant="outline" className="w-full"><Upload className="w-4 h-4 mr-1" />Choose File</Button>
        </Card>
        <Card className="p-5 space-y-2 border-destructive">
          <div className="font-semibold flex items-center gap-2 text-destructive"><RotateCcw className="w-4 h-4" /> Reset to Defaults</div>
          <p className="text-xs text-muted-foreground">⚠️ Deletes all orders, customers, custom products.</p>
          <Button variant="destructive" className="w-full" onClick={() => { if (confirm("Erase everything and restore demo data?")) { resetAll(); toast.success("Reset complete"); }}}>Reset All Data</Button>
        </Card>
      </div>
      <Card className="p-5">
        <div className="text-sm font-semibold mb-2">Quick Stats</div>
        <div className="grid grid-cols-3 gap-3 text-center">
          <div><div className="font-display text-2xl">{orders.length}</div><div className="text-xs text-muted-foreground">Total orders</div></div>
          <div><div className="font-display text-2xl">{fmt(orders.filter((o) => o.status === "paid").reduce((a, o) => a + o.total, 0))}</div><div className="text-xs text-muted-foreground">Lifetime sales</div></div>
          <div><div className="font-display text-2xl">{Math.round(JSON.stringify(orders).length / 1024)} KB</div><div className="text-xs text-muted-foreground">Data size</div></div>
        </div>
      </Card>
    </div>
  );
};
export default Backup;
