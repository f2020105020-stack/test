import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { fmt } from "@/lib/format";
import { format } from "date-fns";
import { WALLET_PROVIDERS, WalletProvider } from "@/types/pos";
import { useMemo, useState } from "react";
import { cn } from "@/lib/utils";

const providerLabel = (v?: WalletProvider) =>
  WALLET_PROVIDERS.find((w) => w.value === v) ?? null;

const OnlinePayments = () => {
  const { orders } = usePOS();
  const [filter, setFilter] = useState<WalletProvider | "all">("all");

  const all = useMemo(
    () => orders.filter((o) => o.paymentMethod === "online" && o.status === "paid"),
    [orders]
  );
  const list = useMemo(
    () => (filter === "all" ? all : all.filter((o) => o.walletProvider === filter)),
    [all, filter]
  );
  const total = list.reduce((a, o) => a + o.total, 0);

  // Per-provider breakdown
  const breakdown = useMemo(() => {
    const map: Record<string, { count: number; sum: number }> = {};
    for (const o of all) {
      const key = o.walletProvider ?? "other";
      map[key] = map[key] ?? { count: 0, sum: 0 };
      map[key].count += 1;
      map[key].sum += o.total;
    }
    return map;
  }, [all]);

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <h2 className="font-display text-4xl">Online Payments</h2>
        <div>
          <span className="text-muted-foreground text-sm">Total received: </span>
          <span className="font-display text-3xl text-primary">{fmt(total)}</span>
        </div>
      </div>

      {/* Provider breakdown */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
        <button
          onClick={() => setFilter("all")}
          className={cn(
            "p-3 rounded-lg border-2 text-left transition",
            filter === "all" ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"
          )}
        >
          <div className="text-xs text-muted-foreground uppercase tracking-wider">All</div>
          <div className="font-display text-xl">{fmt(all.reduce((a, o) => a + o.total, 0))}</div>
          <div className="text-[10px] text-muted-foreground">{all.length} txn</div>
        </button>
        {WALLET_PROVIDERS.map((w) => {
          const b = breakdown[w.value] ?? { count: 0, sum: 0 };
          return (
            <button
              key={w.value}
              onClick={() => setFilter(w.value)}
              className={cn(
                "p-3 rounded-lg border-2 text-left transition",
                filter === w.value ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"
              )}
            >
              <div className="text-xs uppercase tracking-wider flex items-center gap-1">
                <span>{w.emoji}</span>
                <span className="truncate">{w.label}</span>
              </div>
              <div className="font-display text-xl">{fmt(b.sum)}</div>
              <div className="text-[10px] text-muted-foreground">{b.count} txn</div>
            </button>
          );
        })}
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-auto">
          <table className="w-full text-sm">
            <thead className="bg-secondary text-secondary-foreground">
              <tr>
                <th className="p-3 text-left">Order</th>
                <th className="p-3 text-left">Date</th>
                <th className="p-3 text-left">Type</th>
                <th className="p-3 text-left">Provider</th>
                <th className="p-3 text-left">Sender Phone</th>
                <th className="p-3 text-left">Txn ID</th>
                <th className="p-3 text-left">Note</th>
                <th className="p-3 text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {list.map((o) => {
                const prov = providerLabel(o.walletProvider);
                return (
                  <tr key={o.id} className="border-t hover:bg-muted/40">
                    <td className="p-3 font-display">{o.shortId}</td>
                    <td className="p-3 text-muted-foreground whitespace-nowrap">
                      {format(o.paidAt ?? o.createdAt, "yyyy-MM-dd HH:mm")}
                    </td>
                    <td className="p-3 capitalize">
                      <Badge variant="outline">{o.type.replace("-", " ")}</Badge>
                    </td>
                    <td className="p-3">
                      {prov ? (
                        <Badge className="bg-accent text-accent-foreground">
                          <span className="mr-1">{prov.emoji}</span>
                          {prov.label}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                    <td className="p-3 font-mono text-xs">{o.senderPhone ?? "—"}</td>
                    <td className="p-3 font-mono text-xs">{o.transactionId ?? "—"}</td>
                    <td className="p-3 text-xs text-muted-foreground">{o.paymentRef ?? "—"}</td>
                    <td className="p-3 text-right font-mono">{fmt(o.total)}</td>
                  </tr>
                );
              })}
              {list.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center p-12 text-muted-foreground">
                    No online payments {filter !== "all" ? "for this provider" : "yet"}.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default OnlinePayments;
