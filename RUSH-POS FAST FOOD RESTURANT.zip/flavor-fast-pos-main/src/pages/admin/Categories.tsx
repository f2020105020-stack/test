import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const Categories = () => {
  const { categories, products, addCategory, updateCategory, deleteCategory } = usePOS();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ id: "", name: "", emoji: "🍔" });

  const save = () => {
    if (!form.name) return toast.error("Name required");
    if (form.id) updateCategory(form.id, { name: form.name, emoji: form.emoji });
    else addCategory({ name: form.name, emoji: form.emoji });
    setOpen(false); setForm({ id: "", name: "", emoji: "🍔" }); toast.success("Saved");
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-4xl">Categories</h2>
        <Button className="bg-gradient-primary" onClick={() => { setForm({ id: "", name: "", emoji: "🍔" }); setOpen(true); }}><Plus className="w-4 h-4 mr-1" />Add</Button>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {categories.map((c) => {
          const count = products.filter((p) => p.categoryId === c.id).length;
          return (
            <Card key={c.id} className="p-4 flex items-center gap-3">
              <div className="text-4xl">{c.emoji}</div>
              <div className="flex-1">
                <div className="font-semibold">{c.name}</div>
                <div className="text-xs text-muted-foreground">{count} products</div>
              </div>
              <Button size="icon" variant="ghost" onClick={() => { setForm(c); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
              <Button size="icon" variant="ghost" className="text-destructive" onClick={() => { if (confirm(`Delete ${c.name}? This will remove its ${count} products.`)) deleteCategory(c.id); }}><Trash2 className="w-4 h-4" /></Button>
            </Card>
          );
        })}
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{form.id ? "Edit" : "New"} Category</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div><Label>Emoji</Label><Input value={form.emoji} onChange={(e) => setForm({ ...form, emoji: e.target.value })} maxLength={2} /></div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save} className="bg-gradient-primary">Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
export default Categories;
