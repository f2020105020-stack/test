import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Bluetooth, Printer, Save } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { connectPrinter, getConnectedPrinter, printText, buildReceiptText } from "@/lib/printing";

const PrinterPage = () => {
  const { printer, updatePrinter } = usePOS();
  const [device, setDevice] = useState<string | null>(getConnectedPrinter());
  const [busy, setBusy] = useState(false);

  const pair = async () => {
    setBusy(true);
    try {
      const name = await connectPrinter();
      setDevice(name);
      updatePrinter({ deviceName: name });
      toast.success("Paired: " + name);
    } catch (e: any) { toast.error(e.message ?? "Failed"); }
    finally { setBusy(false); }
  };

  const testPrint = async () => {
    try {
      const sample = {
        id: "test", shortId: "TEST", items: [{ productId: "x", name: "Test Burger", price: 450, qty: 1, emoji: "🍔" }],
        subtotal: 450, discountTotal: 0, deliveryCharge: 0, total: 450,
        type: "takeaway" as const, status: "paid" as const, paymentMethod: "cash" as const,
        cashier: "test", createdAt: Date.now(),
      };
      await printText(buildReceiptText(sample as any, printer, "bill"));
      toast.success("Test print sent");
    } catch (e: any) { toast.error(e.message ?? "Print error"); }
  };

  const setLines = (key: "headerLines" | "footerLines", text: string) =>
    updatePrinter({ [key]: text.split("\n").filter((l) => l.trim().length > 0) } as any);

  return (
    <div className="space-y-4 animate-fade-in max-w-2xl">
      <h2 className="font-display text-4xl flex items-center gap-2"><Printer className="w-8 h-8" /> Printer Settings</h2>
      <Card className="p-5 space-y-3">
        <div className="font-semibold">Bluetooth Connection</div>
        <div className="flex items-center gap-3">
          <Bluetooth className={device ? "text-success" : "text-muted-foreground"} />
          <div className="text-sm">{device ? <>Connected to <strong>{device}</strong></> : "No printer connected"}</div>
          <Button size="sm" onClick={pair} disabled={busy}>{busy ? "Pairing…" : "Pair Bluetooth Printer"}</Button>
          <Button size="sm" variant="outline" onClick={testPrint} disabled={!device}>Test Print</Button>
        </div>
        <p className="text-xs text-muted-foreground">Web Bluetooth works in Chrome/Edge on desktop and Android. Pairing requires HTTPS.</p>
      </Card>

      <Card className="p-5 space-y-4">
        <div className="font-semibold">Receipt Configuration</div>
        <div>
          <Label>Paper width</Label>
          <div className="flex gap-2 mt-1">
            {([58, 80] as const).map((w) => (
              <Button key={w} variant={printer.paperWidth === w ? "default" : "outline"} onClick={() => updatePrinter({ paperWidth: w })}>{w}mm</Button>
            ))}
          </div>
        </div>
        <div>
          <Label>Header lines (one per line)</Label>
          <textarea className="w-full border rounded-md p-2 font-mono text-sm bg-background" rows={3}
            defaultValue={printer.headerLines.join("\n")} onBlur={(e) => setLines("headerLines", e.target.value)} />
        </div>
        <div>
          <Label>Footer lines (one per line)</Label>
          <textarea className="w-full border rounded-md p-2 font-mono text-sm bg-background" rows={2}
            defaultValue={printer.footerLines.join("\n")} onBlur={(e) => setLines("footerLines", e.target.value)} />
        </div>
        <label className="flex items-center gap-2">
          <Switch checked={printer.autoPrint} onCheckedChange={(v) => updatePrinter({ autoPrint: v })} /> Auto-print kitchen ticket on order
        </label>
        <Button onClick={() => toast.success("Saved (auto)")} className="bg-gradient-primary"><Save className="w-4 h-4 mr-1" />Save</Button>
      </Card>
    </div>
  );
};
export default PrinterPage;
