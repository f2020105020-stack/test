import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { fmt } from "@/lib/format";
import { startOfMonth, endOfMonth, eachDayOfInterval, format, isWithinInterval } from "date-fns";
import { useMemo } from "react";

const MonthlyReport = () => {
  const { orders } = usePOS();
  const now = new Date();
  const start = startOfMonth(now), end = endOfMonth(now);
  const days = eachDayOfInterval({ start, end });

  const data = useMemo(() => days.map((d) => {
    const dayOrders = orders.filter((o) => o.status === "paid" &&
      isWithinInterval(o.createdAt, { start: new Date(d.setHours(0,0,0,0)), end: new Date(d.setHours(23,59,59,999)) }));
    return { date: d, total: dayOrders.reduce((a, o) => a + o.total, 0), count: dayOrders.length };
  }), [orders, days]);

  const max = Math.max(1, ...data.map((d) => d.total));
  const totalRev = data.reduce((a, d) => a + d.total, 0);
  const totalOrders = data.reduce((a, d) => a + d.count, 0);
  const best = data.reduce((b, d) => d.total > b.total ? d : b, data[0]);
  const worst = data.filter((d) => d.total > 0).reduce((b, d) => d.total < b.total ? d : b, data.find((d) => d.total > 0) ?? data[0]);
  const avg = totalRev / Math.max(1, data.filter((d) => d.total > 0).length);
  const elapsed = now.getDate();
  const projected = avg * data.length;

  return (
    <div className="space-y-4 animate-fade-in">
      <h2 className="font-display text-4xl">Monthly Report · {format(now, "MMMM yyyy")}</h2>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="p-4"><div className="text-xs uppercase text-muted-foreground">Month Total</div><div className="font-display text-3xl text-primary">{fmt(totalRev)}</div><div className="text-xs">{totalOrders} orders</div></Card>
        <Card className="p-4"><div className="text-xs uppercase text-muted-foreground">Avg / day</div><div className="font-display text-3xl">{fmt(avg)}</div></Card>
        <Card className="p-4"><div className="text-xs uppercase text-muted-foreground">Best Day</div><div className="font-display text-2xl">{best && format(best.date, "MMM d")}</div><div className="text-xs">{best && fmt(best.total)}</div></Card>
        <Card className="p-4"><div className="text-xs uppercase text-muted-foreground">Projected</div><div className="font-display text-2xl text-success">{fmt(projected)}</div><div className="text-xs">end of month</div></Card>
      </div>

      <Card className="p-5">
        <div className="text-sm font-semibold mb-3">Daily Sales Trend</div>
        <div className="flex items-end gap-1 h-40">
          {data.map((d) => (
            <div key={d.date.toISOString()} className="flex-1 flex flex-col items-center group" title={`${format(d.date, "MMM d")} — ${fmt(d.total)}`}>
              <div className="w-full bg-gradient-primary rounded-t transition-all hover:opacity-80"
                style={{ height: `${(d.total / max) * 100}%`, minHeight: d.total > 0 ? 2 : 0 }} />
              <div className="text-[9px] mt-1 text-muted-foreground">{format(d.date, "d")}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};
export default MonthlyReport;
