import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { fmt } from "@/lib/format";
import { format } from "date-fns";

const DiscountReport = () => {
  const { orders } = usePOS();
  const rows: any[] = [];
  for (const o of orders) {
    for (const i of o.items) {
      if (i.discountAmount && i.discountAmount > 0) {
        rows.push({ order: o, item: i });
      }
    }
  }
  const total = rows.reduce((a, r) => a + (r.item.discountAmount ?? 0), 0);
  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-end justify-between">
        <h2 className="font-display text-4xl">Discount Report</h2>
        <div><span className="text-muted-foreground text-sm">Total discount given: </span><span className="font-display text-3xl text-accent">{fmt(total)}</span></div>
      </div>
      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-secondary-foreground">
            <tr><th className="p-3 text-left">Order</th><th className="p-3 text-left">Date</th><th className="p-3 text-left">Item</th><th className="p-3 text-left">Type</th><th className="p-3 text-right">Value</th><th className="p-3 text-right">Amount</th><th className="p-3 text-left">Reason</th><th className="p-3 text-left">Cashier</th></tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-t">
                <td className="p-3 font-display">{r.order.shortId}</td>
                <td className="p-3 text-muted-foreground">{format(r.order.createdAt, "yyyy-MM-dd HH:mm")}</td>
                <td className="p-3">{r.item.name}</td>
                <td className="p-3"><Badge variant="outline">{r.item.discountType === "rs" ? "Flat" : "%"}</Badge></td>
                <td className="p-3 text-right font-mono">{r.item.discountValue}{r.item.discountType === "pct" ? "%" : ""}</td>
                <td className="p-3 text-right font-mono text-accent">− {fmt(r.item.discountAmount)}</td>
                <td className="p-3 italic text-muted-foreground">{r.item.discountReason ?? "—"}</td>
                <td className="p-3">{r.order.cashier}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={8} className="text-center p-12 text-muted-foreground">No discounts applied yet.</td></tr>}
          </tbody>
        </table>
      </Card>
    </div>
  );
};
export default DiscountReport;
