import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { fmt } from "@/lib/format";
import { format } from "date-fns";
import { Trash2 } from "lucide-react";

const DeletedOrders = () => {
  const { orders } = usePOS();
  const list = orders.filter((o) => o.status === "deleted");
  return (
    <div className="space-y-4 animate-fade-in">
      <h2 className="font-display text-4xl flex items-center gap-2"><Trash2 className="w-8 h-8 text-destructive" />Deleted Orders</h2>
      <p className="text-sm text-muted-foreground">Audit trail. Deleted orders are kept permanently with their reason.</p>
      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-secondary-foreground">
            <tr><th className="p-3 text-left">Order</th><th className="p-3 text-left">Created</th><th className="p-3 text-left">Deleted</th><th className="p-3 text-left">Reason</th><th className="p-3 text-left">Type</th><th className="p-3 text-right">Total</th></tr>
          </thead>
          <tbody>
            {list.map((o) => (
              <tr key={o.id} className="border-t">
                <td className="p-3 font-display">{o.shortId}</td>
                <td className="p-3 text-muted-foreground">{format(o.createdAt, "yyyy-MM-dd HH:mm")}</td>
                <td className="p-3 text-muted-foreground">{o.deletedAt ? format(o.deletedAt, "yyyy-MM-dd HH:mm") : "—"}</td>
                <td className="p-3 italic">{o.deleteReason}</td>
                <td className="p-3 capitalize"><Badge variant="outline">{o.type.replace("-", " ")}</Badge></td>
                <td className="p-3 text-right font-mono line-through text-muted-foreground">{fmt(o.total)}</td>
              </tr>
            ))}
            {list.length === 0 && <tr><td colSpan={6} className="text-center p-12 text-muted-foreground">No deleted orders.</td></tr>}
          </tbody>
        </table>
      </Card>
    </div>
  );
};
export default DeletedOrders;
