import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Trash2, Pencil, AlertTriangle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";

const TablesAdmin = () => {
  const { tables, addTable, updateTable, deleteTable, freeTable, orders } = usePOS();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ id: "", number: "", capacity: 4 });

  const save = () => {
    if (!form.number) return toast.error("Number required");
    if (form.id) updateTable(form.id, { number: form.number, capacity: form.capacity });
    else addTable({ number: form.number, capacity: form.capacity });
    setOpen(false); setForm({ id: "", number: "", capacity: 4 });
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-4xl">Tables</h2>
        <Button className="bg-gradient-primary" onClick={() => { setForm({ id: "", number: "", capacity: 4 }); setOpen(true); }}><Plus className="w-4 h-4 mr-1" />Add Table</Button>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {tables.map((t) => {
          const order = orders.find((o) => o.id === t.currentOrderId);
          return (
            <Card key={t.id} className="p-4">
              <div className="flex items-center justify-between">
                <div className="font-display text-3xl">{t.number}</div>
                <Badge className={t.status === "busy" ? "bg-primary" : "bg-success text-success-foreground"}>{t.status}</Badge>
              </div>
              <div className="text-xs text-muted-foreground">Capacity {t.capacity}</div>
              {order && <div className="text-xs mt-2">Order <strong>{order.shortId}</strong></div>}
              <div className="flex gap-1 mt-3">
                <Button size="sm" variant="outline" onClick={() => { setForm(t); setOpen(true); }}><Pencil className="w-3 h-3" /></Button>
                {t.status === "busy" && <Button size="sm" variant="outline" className="text-destructive" onClick={() => freeTable(t.id)}><AlertTriangle className="w-3 h-3 mr-1" />Free</Button>}
                <Button size="sm" variant="ghost" className="text-destructive ml-auto" onClick={() => { if (confirm("Delete?")) deleteTable(t.id); }}><Trash2 className="w-3 h-3" /></Button>
              </div>
            </Card>
          );
        })}
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{form.id ? "Edit" : "Add"} Table</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Number</Label><Input value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} /></div>
            <div><Label>Capacity</Label><Input type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })} /></div>
          </div>
          <DialogFooter><Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save} className="bg-gradient-primary">Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
export default TablesAdmin;
