import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { fmt } from "@/lib/format";
import { format } from "date-fns";
import { Wallet, Check } from "lucide-react";
import { PaymentMethod, WalletProvider, WALLET_PROVIDERS } from "@/types/pos";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const CreditSale = () => {
  const { orders, settleCredit } = usePOS();
  const credits = orders.filter((o) => o.status === "credit");
  const settled = orders.filter((o) => o.creditSettledAt);
  const totalCredit = orders.filter((o) => o.creditCustomerName).reduce((a, o) => a + o.total, 0);
  const unpaid = credits.reduce((a, o) => a + o.total, 0);
  const paid = settled.reduce((a, o) => a + o.total, 0);

  const [target, setTarget] = useState<any>(null);
  const [method, setMethod] = useState<PaymentMethod>("cash");
  const [walletProvider, setWalletProvider] = useState<WalletProvider>("jazzcash");
  const [senderPhone, setSenderPhone] = useState("");
  const [txn, setTxn] = useState("");

  return (
    <div className="space-y-4 animate-fade-in">
      <h2 className="font-display text-4xl">Credit Sales</h2>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="p-4"><div className="text-xs text-muted-foreground uppercase">Total Credit Orders</div><div className="font-display text-2xl">{credits.length + settled.length}</div><div className="text-xs">{fmt(totalCredit)}</div></Card>
        <Card className="p-4 border-destructive border-2"><div className="text-xs text-muted-foreground uppercase">Unpaid</div><div className="font-display text-2xl text-destructive">{fmt(unpaid)}</div><div className="text-xs">{credits.length} pending</div></Card>
        <Card className="p-4 border-success border-2"><div className="text-xs text-muted-foreground uppercase">Settled</div><div className="font-display text-2xl text-success">{fmt(paid)}</div><div className="text-xs">{settled.length} paid</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground uppercase">Pending Count</div><div className="font-display text-2xl">{credits.length}</div></Card>
      </div>
      <Card className="overflow-hidden">
        <div className="p-3 bg-muted font-semibold">Outstanding Credits</div>
        <table className="w-full text-sm">
          <thead className="bg-secondary text-secondary-foreground">
            <tr><th className="p-3 text-left">Order</th><th className="p-3 text-left">Customer</th><th className="p-3 text-left">Date</th><th className="p-3 text-left">Type</th><th className="p-3 text-right">Amount</th><th className="p-3 text-right">Action</th></tr>
          </thead>
          <tbody>
            {credits.map((o) => (
              <tr key={o.id} className="border-t">
                <td className="p-3 font-display">{o.shortId}</td>
                <td className="p-3">{o.creditCustomerName ?? o.customerName ?? "—"}</td>
                <td className="p-3 text-muted-foreground">{format(o.createdAt, "yyyy-MM-dd HH:mm")}</td>
                <td className="p-3 capitalize"><Badge variant="outline">{o.type.replace("-", " ")}</Badge></td>
                <td className="p-3 text-right font-mono text-destructive">{fmt(o.total)}</td>
                <td className="p-3 text-right"><Button size="sm" className="bg-success text-success-foreground hover:bg-success/90" onClick={() => { setTarget(o); setMethod("cash"); setTxn(""); setSenderPhone(""); setWalletProvider("jazzcash"); }}><Check className="w-3 h-3 mr-1" />Settle</Button></td>
              </tr>
            ))}
            {credits.length === 0 && <tr><td colSpan={6} className="text-center p-12 text-muted-foreground">No outstanding credits 🎉</td></tr>}
          </tbody>
        </table>
      </Card>

      <Dialog open={!!target} onOpenChange={(v) => !v && setTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Settle Credit · {target?.shortId}</DialogTitle></DialogHeader>
          <div className="text-3xl font-display text-primary text-center">{target && fmt(target.total)}</div>
          <Label>Settlement Method</Label>
          <div className="grid grid-cols-3 gap-2">
            {(["cash", "card", "online"] as const).map((m) => (
              <button key={m} onClick={() => setMethod(m)} className={cn("p-3 rounded-md border-2 capitalize", method === m ? "border-primary bg-primary/5" : "border-border")}>{m}</button>
            ))}
          </div>
          {method === "online" && (
            <div className="space-y-3 border-t pt-3 animate-fade-in">
              <div>
                <Label className="text-xs uppercase tracking-wider text-muted-foreground">Wallet / Transfer</Label>
                <div className="grid grid-cols-3 gap-2 mt-1.5">
                  {WALLET_PROVIDERS.map((w) => (
                    <button key={w.value} type="button" onClick={() => setWalletProvider(w.value)}
                      className={cn("p-2 rounded-md border-2 flex flex-col items-center gap-0.5 text-xs font-medium",
                        walletProvider === w.value ? "border-primary bg-primary/5" : "border-border")}>
                      <span className="text-lg">{w.emoji}</span><span>{w.label}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div><Label>Sender Phone *</Label><Input value={senderPhone} onChange={(e) => setSenderPhone(e.target.value)} placeholder="03XX-XXXXXXX" maxLength={20} /></div>
                <div><Label>Transaction ID *</Label><Input value={txn} onChange={(e) => setTxn(e.target.value)} maxLength={40} /></div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setTarget(null)}>Cancel</Button>
            <Button className="bg-gradient-primary" onClick={() => {
              if (method === "online" && (!senderPhone.trim() || !txn.trim()))
                return toast.error("Sender phone and transaction ID required");
              settleCredit(target.id, method, {
                transactionId: method === "online" ? txn.trim() : undefined,
                walletProvider: method === "online" ? walletProvider : undefined,
                senderPhone: method === "online" ? senderPhone.trim() : undefined,
              });
              toast.success("Credit settled"); setTarget(null);
            }}><Wallet className="w-4 h-4 mr-1" />Confirm</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
export default CreditSale;
