import { usePOS } from "@/store/pos";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Printer, Eye } from "lucide-react";
import { useMemo, useState } from "react";
import { fmt } from "@/lib/format";
import { format } from "date-fns";
import { browserPrint } from "@/lib/printing";
import { ReceiptHTML } from "@/components/ReceiptHTML";
import { renderToString } from "react-dom/server";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const SaleHistory = () => {
  const { orders, printer } = usePOS();
  const [q, setQ] = useState("");
  const [view, setView] = useState<any>(null);

  const list = useMemo(() => orders.filter((o) => o.status === "paid").filter((o) =>
    !q || o.shortId.toLowerCase().includes(q.toLowerCase()) || (o.customerName ?? "").toLowerCase().includes(q.toLowerCase())
  ), [orders, q]);

  return (
    <div className="space-y-4 animate-fade-in">
      <h2 className="font-display text-4xl">Sale History <Badge className="ml-2">{list.length}</Badge></h2>
      <div className="relative max-w-md">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by order ID or customer…" className="pl-9 h-11" />
      </div>
      <Card className="overflow-hidden">
        <div className="overflow-auto">
          <table className="w-full text-sm">
            <thead className="bg-secondary text-secondary-foreground">
              <tr>
                <th className="text-left p-3">Order</th><th className="text-left p-3">Date</th>
                <th className="text-left p-3">Type</th><th className="text-left p-3">Method</th>
                <th className="text-left p-3">Customer</th><th className="text-right p-3">Total</th>
                <th className="text-right p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {list.map((o) => (
                <tr key={o.id} className="border-t hover:bg-muted/40">
                  <td className="p-3 font-display text-base">{o.shortId}</td>
                  <td className="p-3 text-muted-foreground">{format(o.paidAt ?? o.createdAt, "yyyy-MM-dd HH:mm")}</td>
                  <td className="p-3 capitalize">{o.type.replace("-", " ")}</td>
                  <td className="p-3 capitalize"><Badge variant="outline">{o.paymentMethod}</Badge></td>
                  <td className="p-3">{o.customerName ?? (o.tableId ? `Table ${o.tableId}` : "—")}</td>
                  <td className="p-3 text-right font-mono">{fmt(o.total)}</td>
                  <td className="p-3 text-right">
                    <Button size="icon" variant="ghost" onClick={() => setView(o)}><Eye className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => browserPrint(renderToString(<ReceiptHTML order={o} settings={printer} kind="payment" />))}><Printer className="w-4 h-4" /></Button>
                  </td>
                </tr>
              ))}
              {list.length === 0 && <tr><td colSpan={7} className="text-center p-12 text-muted-foreground">No paid sales yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>
      <Dialog open={!!view} onOpenChange={(v) => !v && setView(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Order {view?.shortId}</DialogTitle></DialogHeader>
          {view && (
            <div className="text-sm space-y-1">
              <div className="text-muted-foreground">{format(view.createdAt, "PPpp")}</div>
              <ul className="border-y py-2 space-y-1">
                {view.items.map((i: any) => <li key={i.productId} className="flex justify-between"><span>{i.qty}× {i.name}</span><span className="font-mono">{fmt(i.price * i.qty)}</span></li>)}
              </ul>
              <div className="flex justify-between"><span>Subtotal</span><span className="font-mono">{fmt(view.subtotal)}</span></div>
              {view.discountTotal > 0 && <div className="flex justify-between text-accent"><span>Discount</span><span className="font-mono">− {fmt(view.discountTotal)}</span></div>}
              {view.deliveryCharge > 0 && <div className="flex justify-between"><span>Delivery</span><span className="font-mono">{fmt(view.deliveryCharge)}</span></div>}
              <div className="flex justify-between font-display text-2xl text-primary"><span>TOTAL</span><span>{fmt(view.total)}</span></div>
              <div className="text-xs text-muted-foreground pt-2">Paid: {view.paymentMethod} · Cashier: {view.cashier}</div>
              {view.transactionId && <div className="text-xs">Txn: {view.transactionId}</div>}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SaleHistory;
